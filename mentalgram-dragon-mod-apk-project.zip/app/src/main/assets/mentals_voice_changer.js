// mentals_voice_changer.js - Dedicated Standalone Real-Time Voice Morph Menu (Separate from Mic DSP Menu)
(() => {
  if (window.__mentalsVoiceChangerInstalled) return;
  window.__mentalsVoiceChangerInstalled = true;

  const VOICE_MODES = {
    normal: { label: '🎙️ NORMAL', enabled: false, mode: 'normal', pitch: 1.0, robot: 0, formant: 0, mix: 100 },
    monster: { label: '👺 MONSTER', enabled: true, mode: 'monster', pitch: 0.70, robot: 12, formant: -65, mix: 100 },
    cyborg: { label: '🤖 CYBORG', enabled: true, mode: 'cyborg', pitch: 0.92, robot: 82, formant: 15, mix: 95 },
    alien: { label: '👽 ALIEN', enabled: true, mode: 'alien', pitch: 0.80, robot: 58, formant: -35, mix: 100 },
    high: { label: '👩 HIGH', enabled: true, mode: 'high', pitch: 1.28, robot: 0, formant: 68, mix: 100 },
    chipmunk: { label: '⚡ CHIPMUNK', enabled: true, mode: 'chipmunk', pitch: 1.52, robot: 0, formant: 85, mix: 100 },
  };

  let previewStream = null;

  function getMorphState() {
    if (window.__mentalsGetMorph) return window.__mentalsGetMorph();
    return { enabled: false, mode: 'normal', pitch: 1.0, robot: 0, formant: 0, mix: 100, hearSelf: false };
  }

  function pushMorph(next) {
    if (window.__mentalsApplyMorph) window.__mentalsApplyMorph(next);
  }

  async function toggleHearSelf(nextVal, onDone) {
    if (nextVal) {
      pushMorph({ hearSelf: true });
      const hasVc = window.__mentalsHasActiveVcEngine && window.__mentalsHasActiveVcEngine();
      if (!hasVc && !previewStream && navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        try {
          previewStream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
        } catch {
          pushMorph({ hearSelf: false });
          if (onDone) onDone(false);
          return;
        }
      }
      if (onDone) onDone(true);
    } else {
      pushMorph({ hearSelf: false });
      if (previewStream) {
        previewStream.getTracks().forEach((t) => t.stop());
        previewStream = null;
      }
      if (onDone) onDone(false);
    }
  }

  function mountVoiceChangerUi() {
    if (window.top !== window || document.getElementById('mentals-voice-changer-host')) return;

    const host = document.createElement('div');
    host.id = 'mentals-voice-changer-host';
    host.style.cssText = 'position:fixed;bottom:112px;right:12px;z-index:999998;font-family:system-ui,sans-serif;';
    const shadow = host.attachShadow({ mode: 'open' });

    shadow.innerHTML = `
      <style>
        .fab { background:#18050b; color:#ffb703; border:1px solid #ef233c; padding:7px 12px; font-size:10.5px; font-weight:800; cursor:pointer; clip-path:polygon(8px 0, 100% 0, 100% calc(100% - 8px), calc(100% - 8px) 100%, 0 100%, 0 8px); box-shadow:0 0 14px rgba(239,35,60,0.45); }
        .fab.on { background:linear-gradient(135deg,#ef233c,#9e001c); color:#fff; border-color:#ffb703; }
        .panel { display:none; width:296px; max-height:74vh; overflow-y:auto; background:#070506; border:1px solid #ffb703; padding:11px; color:#f4f4f5; box-shadow:0 16px 40px rgba(0,0,0,0.9); }
        .panel.open { display:block; }
        .head { display:flex; justify-content:space-between; align-items:center; margin-bottom:8px; padding-bottom:7px; border-bottom:1px solid #63141f; gap:5px; }
        .act { background:#140609; border:1px solid #63141f; color:#fff; padding:4px 7px; font-size:9px; font-weight:800; cursor:pointer; }
        .act.on { border-color:#ffb703; background:rgba(239,35,60,0.34); color:#ffb703; }
        .presets { display:grid; grid-template-columns:repeat(3,1fr); gap:5px; margin-bottom:8px; }
        .presets button { background:#12080a; border:1px solid #63141f; color:#f4f4f5; padding:7px 4px; font-size:9.5px; font-weight:800; cursor:pointer; }
        .presets button.active { border-color:#ffb703; background:rgba(239,35,60,0.32); color:#ffb703; }
        .row { background:#12080a; border:1px solid #63141f; padding:7px; margin-bottom:6px; }
        .row-top { display:flex; justify-content:space-between; font-size:9.5px; font-weight:700; margin-bottom:3px; }
        .row-top span:last-child { color:#ffb703; font-family:monospace; }
        input[type=range] { width:100%; accent-color:#ef233c; }
        .note { font-size:9.5px; color:#c9969e; line-height:1.35; }
      </style>
      <button class="fab" id="vcFab">🎭 VOICE</button>
      <div class="panel" id="vcPanel">
        <div class="head">
          <strong style="font-size:12px;color:#ffb703">🎭 VOICE CHANGER</strong>
          <div style="display:flex;gap:4px">
            <button class="act" id="vcPowerBtn">OFF</button>
            <button class="act" id="vcHearBtn">🎧 TEST</button>
            <button class="act" id="vcCloseBtn">X</button>
          </div>
        </div>
        <div class="presets" id="vcPresets"></div>
        <div class="row">
          <div class="row-top"><span>PITCH SHIFT</span><span id="lblPitch">1.00x</span></div>
          <input type="range" id="rngPitch" min="0.55" max="1.65" step="0.01" value="1.00" />
        </div>
        <div class="row">
          <div class="row-top"><span>ROBOT / CYBORG RING</span><span id="lblRobot">0%</span></div>
          <input type="range" id="rngRobot" min="0" max="100" step="1" value="0" />
        </div>
        <div class="row">
          <div class="row-top"><span>FORMANT TONE</span><span id="lblFormant">0%</span></div>
          <input type="range" id="rngFormant" min="-100" max="100" step="1" value="0" />
        </div>
        <div class="row">
          <div class="row-top"><span>MORPH MIX</span><span id="lblMix">100%</span></div>
          <input type="range" id="rngMix" min="0" max="100" step="1" value="100" />
        </div>
        <div class="note">Alag Voice Changer Menu · Live VC &amp; Voice Notes dono par real-time kaam karta hai.</div>
      </div>
    `;

    const vcFab = shadow.getElementById('vcFab');
    const vcPanel = shadow.getElementById('vcPanel');
    const vcPowerBtn = shadow.getElementById('vcPowerBtn');
    const vcHearBtn = shadow.getElementById('vcHearBtn');
    const vcPresets = shadow.getElementById('vcPresets');

    const rngPitch = shadow.getElementById('rngPitch');
    const rngRobot = shadow.getElementById('rngRobot');
    const rngFormant = shadow.getElementById('rngFormant');
    const rngMix = shadow.getElementById('rngMix');

    function syncUi() {
      const s = getMorphState();
      vcFab.classList.toggle('on', Boolean(s.enabled));
      vcFab.textContent = s.enabled ? '🎭 MORPH ON' : '🎭 VOICE';

      vcPowerBtn.textContent = s.enabled ? 'MORPH ON' : 'MORPH OFF';
      vcPowerBtn.classList.toggle('on', Boolean(s.enabled));

      vcHearBtn.classList.toggle('on', Boolean(s.hearSelf));
      vcHearBtn.textContent = s.hearSelf ? '🎧 LIVE' : '🎧 TEST';

      rngPitch.value = String(s.pitch || 1.0);
      rngRobot.value = String(s.robot || 0);
      rngFormant.value = String(s.formant || 0);
      rngMix.value = String(s.mix ?? 100);

      shadow.getElementById('lblPitch').textContent = Number(s.pitch || 1.0).toFixed(2) + 'x';
      shadow.getElementById('lblRobot').textContent = (s.robot || 0) + '%';
      shadow.getElementById('lblFormant').textContent = (s.formant > 0 ? '+' : '') + (s.formant || 0) + '%';
      shadow.getElementById('lblMix').textContent = (s.mix ?? 100) + '%';

      shadow.querySelectorAll('#vcPresets button').forEach((b) => {
        b.classList.toggle('active', b.getAttribute('data-m') === s.mode && (s.enabled || s.mode === 'normal'));
      });
    }

    Object.keys(VOICE_MODES).forEach((k) => {
      const m = VOICE_MODES[k];
      const b = document.createElement('button');
      b.setAttribute('data-m', k);
      b.textContent = m.label;
      b.addEventListener('click', () => {
        pushMorph({ enabled: m.enabled, mode: m.mode, pitch: m.pitch, robot: m.robot, formant: m.formant, mix: m.mix });
        syncUi();
      });
      vcPresets.appendChild(b);
    });

    vcPowerBtn.addEventListener('click', () => {
      const s = getMorphState();
      pushMorph({ enabled: !s.enabled });
      syncUi();
    });

    vcHearBtn.addEventListener('click', () => {
      const s = getMorphState();
      toggleHearSelf(!s.hearSelf, () => syncUi());
    });

    rngPitch.addEventListener('input', () => {
      pushMorph({ enabled: true, mode: 'custom', pitch: Number(rngPitch.value) });
      syncUi();
    });
    rngRobot.addEventListener('input', () => {
      pushMorph({ enabled: true, mode: 'custom', robot: Number(rngRobot.value) });
      syncUi();
    });
    rngFormant.addEventListener('input', () => {
      pushMorph({ enabled: true, mode: 'custom', formant: Number(rngFormant.value) });
      syncUi();
    });
    rngMix.addEventListener('input', () => {
      pushMorph({ mix: Number(rngMix.value) });
      syncUi();
    });

    vcFab.addEventListener('click', () => {
      if (window.__mentalsCloseMicMenu) window.__mentalsCloseMicMenu();
      syncUi();
      vcPanel.classList.add('open');
      vcFab.style.display = 'none';
    });

    shadow.getElementById('vcCloseBtn').addEventListener('click', () => {
      vcPanel.classList.remove('open');
      vcFab.style.display = 'inline-block';
    });

    window.__mentalsCloseVoiceChanger = () => {
      vcPanel.classList.remove('open');
      vcFab.style.display = 'inline-block';
    };
    window.__mentalsOnPipChanger = (inPip) => {
      host.style.display = inPip ? 'none' : 'block';
    };

    syncUi();
    document.documentElement.appendChild(host);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', mountVoiceChangerUi);
  } else {
    mountVoiceChangerUi();
  }
})();
