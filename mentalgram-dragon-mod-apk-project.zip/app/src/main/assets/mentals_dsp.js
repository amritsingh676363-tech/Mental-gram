// ==UserScript==
// @name         👑 MENTALS (Dragon Telegram Mic DSP v3.0)
// @namespace    https://web.telegram.org/
// @version      3.0.0
// @description  Dragon Style Telegram Mic DSP with Sub-Bass Exciter, Soundboard, VU Bar & Real-Time Pitch/Morph Engine Hooks
// @author       MENTALS DRAGON LAB
// @match        https://web.telegram.org/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(() => {
  if (window.__tgVoiceUserscriptLoaded) return;
  window.__tgVoiceUserscriptLoaded = true;

  const STORAGE_KEY = 'mentals_dragon_userscript_cfg_v33';
  const MORPH_KEY = 'mentals_voice_morph_cfg_v30';
  const LIMITER_ENABLED = true;
  const PRESETS = {
    dragonRoar: { ...{"micGain":480,"bass":72,"treble":68,"voiceClarity":92,"echo":0,"loudness":94,"noiseControl":28}, subBass: 82 },
    demonBeast: { micGain: 680, bass: 92, treble: 56, voiceClarity: 96, echo: 16, loudness: 98, noiseControl: 28, subBass: 100 },
    radioStudio: { ...{"micGain":240,"bass":30,"treble":50,"voiceClarity":74,"echo":0,"loudness":62,"noiseControl":24}, subBass: 40 },
    shadowStealth: { ...{"micGain":250,"bass":52,"treble":38,"voiceClarity":64,"echo":10,"loudness":65,"noiseControl":42}, subBass: 60 },
  };

  let settings = { subBass: 82, overdrive: true, antiDuck: true, ...{"micGain":214,"bass":0,"treble":46,"voiceClarity":3,"echo":100,"loudness":10,"noiseControl":15} };
  let morphCfg = {
    enabled: false,
    mode: 'normal',
    pitch: 1.0,
    robot: 0,
    formant: 0,
    mix: 100,
    hearSelf: false,
  };
  let isMuted = false;
  let isBypassed = false;
  let customAudioBuffer = null;

  try {
    const saved = localStorage.getItem(STORAGE_KEY) || localStorage.getItem('mentals_dragon_userscript_cfg_v25');
    if (saved) settings = { ...settings, ...JSON.parse(saved) };
    const savedM = localStorage.getItem(MORPH_KEY);
    if (savedM) morphCfg = { ...morphCfg, ...JSON.parse(savedM), hearSelf: false };
  } catch {}

  const activeEngines = new Set();

  function makeSoftClipCurve(drive) {
    const samples = 1024;
    const curve = new Float32Array(samples);
    const k = Math.max(0.5, drive);
    const norm = Math.tanh(k);
    for (let i = 0; i < samples; i++) {
      const x = (i * 2) / samples - 1;
      curve[i] = Math.tanh(k * x) / norm;
    }
    return curve;
  }

  function makeSubHarmonicCurve() {
    const samples = 1024;
    const curve = new Float32Array(samples);
    for (let i = 0; i < samples; i++) {
      const x = (i * 2) / samples - 1;
      curve[i] = Math.tanh(2.4 * x + 0.35 * x * x);
    }
    return curve;
  }

  function applyMorphToEngine(engine, mc) {
    const {
      ctx,
      morphDry,
      morphWet,
      baseDelaySrc,
      depthGainA,
      depthGainB,
      tGrain,
      formantFilter,
      ringGain,
      ringDepth,
      ringOsc,
      selfMonitorGain,
    } = engine;
    if (!ctx || ctx.state === 'closed') return;
    const now = ctx.currentTime;

    selfMonitorGain.gain.setTargetAtTime(mc.hearSelf ? 0.85 : 0, now, 0.02);

    if (!mc.enabled || mc.mix <= 0) {
      morphDry.gain.setTargetAtTime(1.0, now, 0.02);
      morphWet.gain.setTargetAtTime(0.0, now, 0.02);
      ringDepth.gain.setTargetAtTime(0.0, now, 0.02);
      ringGain.gain.setTargetAtTime(1.0, now, 0.02);
      return;
    }

    const wet = Math.max(0, Math.min(1, mc.mix / 100));
    morphDry.gain.setTargetAtTime(1 - wet, now, 0.02);
    morphWet.gain.setTargetAtTime(wet, now, 0.02);

    const p = Math.max(0.55, Math.min(1.65, Number(mc.pitch) || 1.0));
    let baseDelay = 0.004;
    let depth = 0;
    if (p < 1.0) {
      depth = (1.0 - p) * tGrain;
      baseDelay = 0.004;
    } else if (p > 1.0) {
      depth = -(p - 1.0) * tGrain;
      baseDelay = (p - 1.0) * tGrain + 0.004;
    }
    baseDelaySrc.offset.setTargetAtTime(baseDelay, now, 0.02);
    depthGainA.gain.setTargetAtTime(depth, now, 0.02);
    depthGainB.gain.setTargetAtTime(depth, now, 0.02);

    const fVal = Math.max(-100, Math.min(100, Number(mc.formant) || 0));
    const freq = fVal >= 0 ? 1100 + (fVal / 100) * 1700 : 1100 - (Math.abs(fVal) / 100) * 760;
    formantFilter.frequency.setTargetAtTime(freq, now, 0.02);
    formantFilter.gain.setTargetAtTime(Math.abs(fVal) > 5 ? 9.5 : 0, now, 0.02);

    const rAmt = Math.max(0, Math.min(1, (Number(mc.robot) || 0) / 100));
    ringOsc.frequency.setTargetAtTime(mc.mode === 'alien' ? 34 : 64, now, 0.02);
    ringGain.gain.setTargetAtTime(1.0 - rAmt * 0.72, now, 0.02);
    ringDepth.gain.setTargetAtTime(rAmt * 0.72, now, 0.02);
  }

  function applySettings(engine, cfg) {
    const {
      ctx,
      gainNode,
      noiseFilter,
      subGain,
      bassFilter,
      midPowerFilter,
      clarityFilter,
      trebleFilter,
      compressor,
      makeupGain,
      saturator,
      postBoost,
      limiter,
      echoWet,
      echoFeedback,
    } = engine;
    if (!ctx || ctx.state === 'closed') return;
    const now = ctx.currentTime;

    if (isMuted) {
      gainNode.gain.setTargetAtTime(0, now, 0.015);
      subGain.gain.setTargetAtTime(0, now, 0.015);
      return;
    }

    if (isBypassed) {
      gainNode.gain.setTargetAtTime(1.0, now, 0.02);
      noiseFilter.frequency.setTargetAtTime(20, now, 0.02);
      subGain.gain.setTargetAtTime(0, now, 0.02);
      bassFilter.gain.setTargetAtTime(0, now, 0.02);
      midPowerFilter.gain.setTargetAtTime(0, now, 0.02);
      clarityFilter.gain.setTargetAtTime(0, now, 0.02);
      trebleFilter.gain.setTargetAtTime(0, now, 0.02);
      compressor.threshold.setTargetAtTime(0, now, 0.02);
      compressor.ratio.setTargetAtTime(1, now, 0.02);
      makeupGain.gain.setTargetAtTime(1.0, now, 0.02);
      saturator.curve = makeSoftClipCurve(0.5);
      postBoost.gain.setTargetAtTime(1.0, now, 0.02);
      limiter.threshold.setTargetAtTime(0, now, 0.02);
      limiter.ratio.setTargetAtTime(1, now, 0.02);
      echoWet.gain.setTargetAtTime(0, now, 0.02);
      echoFeedback.gain.setTargetAtTime(0, now, 0.02);
      return;
    }

    const boostMult = cfg.overdrive !== false ? 1.65 : 1.0;
    const baseGain = Math.max(0, Math.min(10.0, (cfg.micGain || 0) / 100));
    gainNode.gain.setTargetAtTime(Math.min(14.0, baseGain * boostMult), now, 0.02);
    noiseFilter.frequency.setTargetAtTime(20 + (cfg.noiseControl / 100) * 180, now, 0.02);
    subGain.gain.setTargetAtTime(((cfg.subBass || 0) / 100) * 1.55, now, 0.02);
    bassFilter.gain.setTargetAtTime((cfg.bass / 100) * 18, now, 0.02);
    midPowerFilter.gain.setTargetAtTime((cfg.overdrive !== false ? 5.5 : 2.0) + (cfg.loudness / 100) * 6.0, now, 0.02);
    clarityFilter.gain.setTargetAtTime((cfg.voiceClarity / 100) * 20, now, 0.02);
    trebleFilter.gain.setTargetAtTime((cfg.treble / 100) * 16, now, 0.02);
    compressor.threshold.setTargetAtTime(-10 - (cfg.loudness / 100) * 30, now, 0.025);
    compressor.ratio.setTargetAtTime(2.5 + (cfg.loudness / 100) * 9.5, now, 0.025);
    makeupGain.gain.setTargetAtTime((1.2 + (cfg.loudness / 100) * 6.5) * (cfg.overdrive !== false ? 1.35 : 1.0), now, 0.02);
    saturator.curve = makeSoftClipCurve(LIMITER_ENABLED ? 2.4 + (cfg.loudness / 100) * 7.2 : 0.5);
    postBoost.gain.setTargetAtTime((1.0 + (cfg.loudness / 100) * 0.45) * (cfg.overdrive !== false ? 1.18 : 1.0), now, 0.02);
    limiter.threshold.setTargetAtTime(LIMITER_ENABLED ? -0.3 : 0, now, 0.02);
    limiter.ratio.setTargetAtTime(LIMITER_ENABLED ? 20 : 1, now, 0.02);
    echoWet.gain.setTargetAtTime((cfg.echo / 100) * 0.65, now, 0.03);
    echoFeedback.gain.setTargetAtTime(Math.min(0.5, (cfg.echo / 100) * 0.45), now, 0.03);
  }

  function playSynthSfxOnContext(ctx, targetNode, monitorNode, type) {
    const now = ctx.currentTime;
    const masterSfx = ctx.createGain();
    masterSfx.gain.setValueAtTime(0.85, now);
    if (targetNode) masterSfx.connect(targetNode);
    if (monitorNode) {
      const mon = ctx.createGain();
      mon.gain.value = 0.28;
      masterSfx.connect(mon);
      mon.connect(monitorNode);
    }

    if (type === 'roar') {
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const filt = ctx.createBiquadFilter();
      const env = ctx.createGain();
      osc1.type = 'sawtooth';
      osc2.type = 'triangle';
      osc1.frequency.setValueAtTime(140, now);
      osc1.frequency.exponentialRampToValueAtTime(52, now + 0.95);
      osc2.frequency.setValueAtTime(95, now);
      osc2.frequency.exponentialRampToValueAtTime(38, now + 0.95);
      filt.type = 'lowpass';
      filt.frequency.setValueAtTime(900, now);
      filt.frequency.exponentialRampToValueAtTime(220, now + 0.95);
      env.gain.setValueAtTime(0.01, now);
      env.gain.linearRampToValueAtTime(0.95, now + 0.08);
      env.gain.exponentialRampToValueAtTime(0.001, now + 1.05);
      osc1.connect(filt); osc2.connect(filt); filt.connect(env); env.connect(masterSfx);
      osc1.start(now); osc2.start(now);
      osc1.stop(now + 1.08); osc2.stop(now + 1.08);
    } else if (type === 'boom') {
      const osc = ctx.createOscillator();
      const env = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(150, now);
      osc.frequency.exponentialRampToValueAtTime(34, now + 0.55);
      env.gain.setValueAtTime(1.0, now);
      env.gain.exponentialRampToValueAtTime(0.001, now + 0.72);
      osc.connect(env); env.connect(masterSfx);
      osc.start(now); osc.stop(now + 0.75);
    } else if (type === 'thunder') {
      const len = Math.floor(ctx.sampleRate * 1.1);
      const buf = ctx.createBuffer(1, len, ctx.sampleRate);
      const ch = buf.getChannelData(0);
      for (let i = 0; i < len; i++) ch[i] = (Math.random() * 2 - 1) * Math.exp(-i / (ctx.sampleRate * 0.45));
      const src = ctx.createBufferSource();
      src.buffer = buf;
      const lp = ctx.createBiquadFilter();
      lp.type = 'lowpass';
      lp.frequency.setValueAtTime(480, now);
      lp.frequency.exponentialRampToValueAtTime(95, now + 1.05);
      src.connect(lp); lp.connect(masterSfx);
      src.start(now);
    } else if (type === 'custom' && customAudioBuffer) {
      const src = ctx.createBufferSource();
      src.buffer = customAudioBuffer;
      src.connect(masterSfx);
      src.start(now);
    }
  }

  function triggerSfx(type) {
    if (activeEngines.size > 0) {
      activeEngines.forEach((e) => {
        if (e.ctx.state === 'suspended') e.ctx.resume().catch(() => {});
        playSynthSfxOnContext(e.ctx, e.limiter, e.ctx.destination, type);
      });
    } else {
      try {
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        const tmp = new AudioCtx();
        playSynthSfxOnContext(tmp, null, tmp.destination, type);
        setTimeout(() => tmp.close().catch(() => {}), 2500);
      } catch {}
    }
  }

  function showMiniToast(msg) {
    let t = document.getElementById('mentals-dsp-toast');
    if (!t) {
      t = document.createElement('div');
      t.id = 'mentals-dsp-toast';
      t.style.cssText = 'position:fixed;top:52px;left:50%;transform:translateX(-50%);background:#140508;color:#ffb703;border:1px solid #ef233c;padding:6px 14px;font-size:11px;font-weight:800;font-family:monospace;z-index:2147483647;box-shadow:0 4px 18px rgba(239,35,60,0.45);pointer-events:none;';
      document.documentElement.appendChild(t);
    }
    t.textContent = msg;
    t.style.display = 'block';
    clearTimeout(t._timer);
    t._timer = setTimeout(() => { t.style.display = 'none'; }, 1700);
  }

  window.__mentalsGetMorph = () => ({ ...morphCfg });
  window.__mentalsApplyMorph = (next) => {
    morphCfg = { ...morphCfg, ...next };
    try {
      const toSave = { ...morphCfg, hearSelf: false };
      localStorage.setItem(MORPH_KEY, JSON.stringify(toSave));
    } catch {}
    activeEngines.forEach((e) => applyMorphToEngine(e, morphCfg));
  };

  window.__mentalsGetMicStream = () => {
    for (const e of activeEngines) {
      if (e.destination && e.destination.stream) return e.destination.stream;
    }
    return null;
  };

  window.__mentalsHasActiveVcEngine = () => activeEngines.size > 0;

  window.__mentalsToggleMute = () => {
    isMuted = !isMuted;
    activeEngines.forEach((e) => applySettings(e, settings));
    window.dispatchEvent(new CustomEvent('mentals-dsp-state'));
    showMiniToast(isMuted ? '🔇 MIC MUTED' : '🎙️ MIC LIVE');
  };

  window.__mentalsToggleBypass = () => {
    isBypassed = !isBypassed;
    activeEngines.forEach((e) => applySettings(e, settings));
    window.dispatchEvent(new CustomEvent('mentals-dsp-state'));
    showMiniToast(isBypassed ? '⚡ RAW MIC (BYPASS)' : '🐉 DRAGON DSP ARMED');
  };

  window.__mentalsTriggerSfx = (type) => {
    triggerSfx(type || 'roar');
    showMiniToast('🔊 SFX: ' + String(type || 'roar').toUpperCase());
  };

  window.__mentalsOnVolKey = (dir, mode) => {
    if (mode === 'MUTE') {
      if (dir === 'DOWN') window.__mentalsToggleMute();
      else window.__mentalsToggleBypass();
    } else if (mode === 'SFX') {
      if (dir === 'UP') window.__mentalsTriggerSfx('roar');
      else window.__mentalsTriggerSfx('boom');
    }
  };

  // WebRTC 128kbps Opus & High-Priority Voice Hook so opponent mics cannot bury your audio
  if (window.RTCPeerConnection && !window.__mentalsDspRtcHooked) {
    window.__mentalsDspRtcHooked = true;
    const origSetLocal = RTCPeerConnection.prototype.setLocalDescription;
    if (origSetLocal) {
      RTCPeerConnection.prototype.setLocalDescription = function (desc) {
        try {
          if (desc && desc.sdp && desc.sdp.includes('opus')) {
            const nextSdp = desc.sdp.replace(/a=fmtp:(\d+)\s+([^\r\n]+)/g, (m, pt, params) => {
              if (!desc.sdp.includes('a=rtpmap:' + pt + ' opus')) return m;
              let clean = params
                .replace(/;?\s*maxaveragebitrate=\d+/g, '')
                .replace(/;?\s*usedtx=\d+/g, '')
                .replace(/;?\s*cbr=\d+/g, '');
              return 'a=fmtp:' + pt + ' ' + clean + ';maxaveragebitrate=128000;usedtx=0;cbr=1;maxplaybackrate=48000';
            });
            desc = new RTCSessionDescription({ type: desc.type, sdp: nextSdp });
          }
        } catch {}
        return origSetLocal.call(this, desc);
      };
    }
    const origAddTrack = RTCPeerConnection.prototype.addTrack;
    if (origAddTrack) {
      RTCPeerConnection.prototype.addTrack = function (track, ...streams) {
        const sender = origAddTrack.call(this, track, ...streams);
        if (track && track.kind === 'audio' && sender && sender.getParameters && sender.setParameters) {
          setTimeout(() => {
            try {
              const p = sender.getParameters();
              if (p.encodings && p.encodings.length) {
                p.encodings[0].maxBitrate = 128000;
                p.encodings[0].priority = 'high';
                sender.setParameters(p).catch(() => {});
              }
            } catch {}
          }, 450);
        }
        return sender;
      };
    }
  }

  if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
    const orig = navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);
    navigator.mediaDevices.getUserMedia = async function (constraints) {
      let mod = constraints;
      let basicMod = constraints;
      if (constraints && constraints.audio) {
        const audioObj = typeof constraints.audio === 'object' ? { ...constraints.audio } : {};
        const noDuck = settings.antiDuck !== false;
        basicMod = {
          ...constraints,
          audio: {
            ...audioObj,
            echoCancellation: !noDuck,
            noiseSuppression: false,
            autoGainControl: false
          }
        };
        mod = {
          ...constraints,
          audio: {
            ...audioObj,
            echoCancellation: !noDuck,
            noiseSuppression: false,
            autoGainControl: false,
            googEchoCancellation: !noDuck,
            googAutoGainControl: false,
            googNoiseSuppression: false,
            googHighpassFilter: false,
            googTypingNoiseDetection: false
          }
        };
      }
      let rawStream;
      try {
        rawStream = await orig(mod);
      } catch {
        try { rawStream = await orig(basicMod); } catch { rawStream = await orig(constraints); }
      }
      if (!constraints || !constraints.audio || rawStream.getAudioTracks().length === 0) return rawStream;
      try {
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        const ctx = new AudioCtx();
        if (ctx.state === 'suspended') await ctx.resume();
        const source = ctx.createMediaStreamSource(rawStream);
        const gainNode = ctx.createGain();
        const noiseFilter = ctx.createBiquadFilter(); noiseFilter.type = 'highpass'; noiseFilter.Q.value = 0.707;

        // Real-Time Dual-Delay Hann Pitch Shifter + Formant + Cyborg Ring Modulator
        const morphDry = ctx.createGain();
        const morphWet = ctx.createGain();
        const morphSum = ctx.createGain();
        const delayA = ctx.createDelay(0.5); delayA.delayTime.value = 0;
        const delayB = ctx.createDelay(0.5); delayB.delayTime.value = 0;
        const winGainA = ctx.createGain(); winGainA.gain.value = 0;
        const winGainB = ctx.createGain(); winGainB.gain.value = 0;

        const N_GRAIN = 4096;
        const tGrain = N_GRAIN / ctx.sampleRate;
        const sawBufA = ctx.createBuffer(1, N_GRAIN, ctx.sampleRate);
        const sawBufB = ctx.createBuffer(1, N_GRAIN, ctx.sampleRate);
        const winBufA = ctx.createBuffer(1, N_GRAIN, ctx.sampleRate);
        const winBufB = ctx.createBuffer(1, N_GRAIN, ctx.sampleRate);
        const sA = sawBufA.getChannelData(0), sB = sawBufB.getChannelData(0);
        const wA = winBufA.getChannelData(0), wB = winBufB.getChannelData(0);
        for (let i = 0; i < N_GRAIN; i++) {
          const pA = i / N_GRAIN;
          const pB = ((i + (N_GRAIN >> 1)) % N_GRAIN) / N_GRAIN;
          sA[i] = pA; sB[i] = pB;
          wA[i] = 0.5 * (1 - Math.cos(2 * Math.PI * pA));
          wB[i] = 0.5 * (1 - Math.cos(2 * Math.PI * pB));
        }
        const sawSrcA = ctx.createBufferSource(); sawSrcA.buffer = sawBufA; sawSrcA.loop = true;
        const sawSrcB = ctx.createBufferSource(); sawSrcB.buffer = sawBufB; sawSrcB.loop = true;
        const winSrcA = ctx.createBufferSource(); winSrcA.buffer = winBufA; winSrcA.loop = true;
        const winSrcB = ctx.createBufferSource(); winSrcB.buffer = winBufB; winSrcB.loop = true;

        const baseDelaySrc = ctx.createConstantSource(); baseDelaySrc.offset.value = 0.004;
        const depthGainA = ctx.createGain(); depthGainA.gain.value = 0;
        const depthGainB = ctx.createGain(); depthGainB.gain.value = 0;

        baseDelaySrc.connect(delayA.delayTime);
        baseDelaySrc.connect(delayB.delayTime);
        sawSrcA.connect(depthGainA); depthGainA.connect(delayA.delayTime);
        sawSrcB.connect(depthGainB); depthGainB.connect(delayB.delayTime);
        winSrcA.connect(winGainA.gain);
        winSrcB.connect(winGainB.gain);

        const formantFilter = ctx.createBiquadFilter(); formantFilter.type = 'peaking'; formantFilter.frequency.value = 1100; formantFilter.Q.value = 1.4;
        const ringGain = ctx.createGain(); ringGain.gain.value = 1;
        const ringOsc = ctx.createOscillator(); ringOsc.type = 'sine'; ringOsc.frequency.value = 64;
        const ringDepth = ctx.createGain(); ringDepth.gain.value = 0;
        ringOsc.connect(ringDepth); ringDepth.connect(ringGain.gain);

        const t0 = ctx.currentTime + 0.01;
        sawSrcA.start(t0); sawSrcB.start(t0); winSrcA.start(t0); winSrcB.start(t0);
        baseDelaySrc.start(t0); ringOsc.start(t0);

        // Parallel Sub-Bass Harmonic Exciter
        const subBand = ctx.createBiquadFilter(); subBand.type = 'bandpass'; subBand.frequency.value = 120; subBand.Q.value = 0.8;
        const subShaper = ctx.createWaveShaper(); subShaper.curve = makeSubHarmonicCurve();
        const subLP = ctx.createBiquadFilter(); subLP.type = 'lowpass'; subLP.frequency.value = 115;
        const subGain = ctx.createGain(); subGain.gain.value = 0.7;

        const bassFilter = ctx.createBiquadFilter(); bassFilter.type = 'lowshelf'; bassFilter.frequency.value = 110;
        const midPowerFilter = ctx.createBiquadFilter(); midPowerFilter.type = 'peaking'; midPowerFilter.frequency.value = 1350; midPowerFilter.Q.value = 0.85;
        const clarityFilter = ctx.createBiquadFilter(); clarityFilter.type = 'peaking'; clarityFilter.frequency.value = 2550; clarityFilter.Q.value = 0.95;
        const trebleFilter = ctx.createBiquadFilter(); trebleFilter.type = 'highshelf'; trebleFilter.frequency.value = 6200;
        const compressor = ctx.createDynamicsCompressor(); compressor.knee.value = 8; compressor.attack.value = 0.0015; compressor.release.value = 0.055;
        const makeupGain = ctx.createGain();
        const saturator = ctx.createWaveShaper(); saturator.oversample = 'none';
        const postBoost = ctx.createGain(); postBoost.gain.value = 1.25;
        const limiter = ctx.createDynamicsCompressor(); limiter.knee.value = 0; limiter.attack.value = 0.0005; limiter.release.value = 0.03;
        const dryGain = ctx.createGain();
        const delayNode = ctx.createDelay(1.0); delayNode.delayTime.value = 0.22;
        const echoFeedback = ctx.createGain();
        const echoWet = ctx.createGain();
        const analyser = ctx.createAnalyser(); analyser.fftSize = 128;
        const destination = ctx.createMediaStreamDestination();
        const selfMonitorGain = ctx.createGain(); selfMonitorGain.gain.value = 0;

        source.connect(gainNode);
        gainNode.connect(noiseFilter);

        // Voice Morph Stage
        noiseFilter.connect(morphDry);
        morphDry.connect(morphSum);
        noiseFilter.connect(delayA); delayA.connect(winGainA); winGainA.connect(formantFilter);
        noiseFilter.connect(delayB); delayB.connect(winGainB); winGainB.connect(formantFilter);
        formantFilter.connect(ringGain); ringGain.connect(morphWet); morphWet.connect(morphSum);

        // Main EQ path + Sub-Bass + Anti-Suppression Mid Cut
        morphSum.connect(bassFilter);
        bassFilter.connect(midPowerFilter);
        midPowerFilter.connect(clarityFilter);
        clarityFilter.connect(trebleFilter);
        trebleFilter.connect(compressor);

        morphSum.connect(subBand);
        subBand.connect(subShaper);
        subShaper.connect(subLP);
        subLP.connect(subGain);
        subGain.connect(compressor);

        compressor.connect(makeupGain);
        makeupGain.connect(saturator);
        saturator.connect(dryGain);
        dryGain.connect(postBoost);
        saturator.connect(delayNode);
        delayNode.connect(echoFeedback);
        echoFeedback.connect(delayNode);
        delayNode.connect(echoWet);
        echoWet.connect(postBoost);
        postBoost.connect(limiter);
        limiter.connect(analyser);
        analyser.connect(destination);
        limiter.connect(selfMonitorGain);
        selfMonitorGain.connect(ctx.destination);

        const engine = {
          ctx, gainNode, noiseFilter, subGain, bassFilter, midPowerFilter, clarityFilter, trebleFilter,
          compressor, makeupGain, saturator, postBoost, limiter, echoWet, echoFeedback, analyser, destination,
          morphDry, morphWet, baseDelaySrc, depthGainA, depthGainB, tGrain, formantFilter, ringGain, ringDepth, ringOsc, selfMonitorGain
        };
        applySettings(engine, settings);
        applyMorphToEngine(engine, morphCfg);
        activeEngines.add(engine);

        const out = new MediaStream();
        destination.stream.getAudioTracks().forEach((t) => {
          const stop = t.stop.bind(t);
          t.stop = () => {
            try { sawSrcA.stop(); sawSrcB.stop(); winSrcA.stop(); winSrcB.stop(); baseDelaySrc.stop(); ringOsc.stop(); } catch {}
            rawStream.getAudioTracks().forEach((r) => r.stop());
            activeEngines.delete(engine);
            if (ctx.state !== 'closed') ctx.close();
            stop();
          };
          out.addTrack(t);
        });
        rawStream.getVideoTracks().forEach((v) => out.addTrack(v));
        return out;
      } catch {
        return rawStream;
      }
    };
  }

  function mountUi() {
    if (window.top !== window || document.getElementById('mentals-us-mic-host')) return;
    const POS_KEY = 'mentals_mic_fab_pos_v1';
    const host = document.createElement('div');
    host.id = 'mentals-us-mic-host';
    host.style.cssText = 'position:fixed;top:92px;right:10px;z-index:999998;font-family:system-ui,sans-serif;';
    try {
      const savedPos = JSON.parse(localStorage.getItem(POS_KEY) || 'null');
      if (savedPos && typeof savedPos.left === 'number' && typeof savedPos.top === 'number') {
        host.style.right = 'auto';
        host.style.bottom = 'auto';
        host.style.left = Math.max(8, Math.min(window.innerWidth - 110, savedPos.left)) + 'px';
        host.style.top = Math.max(8, Math.min(window.innerHeight - 44, savedPos.top)) + 'px';
      }
    } catch {}
    const shadow = host.attachShadow({ mode: 'open' });
    shadow.innerHTML = `
      <style>
        .fab { background:#1c140b; color:#fde047; border:1px solid #f59e0b; padding:7px 12px; font-size:10.5px; font-weight:800; cursor:grab; touch-action:none; user-select:none; -webkit-user-select:none; clip-path:polygon(8px 0, 100% 0, 100% calc(100% - 8px), calc(100% - 8px) 100%, 0 100%, 0 8px); box-shadow:0 0 14px rgba(245, 158, 11, 0.5); }
        .panel { display:none; position:fixed; top:50%; left:50%; transform:translate(-50%,-50%); width:min(306px, 92vw); max-height:78vh; overflow-y:auto; z-index:999999; background:#120d07; border:1px solid #f59e0b; padding:11px; color:#f4f4f5; box-shadow:0 16px 40px rgba(0,0,0,0.88); }
        .panel.open { display:block; }
        .head { display:flex; justify-content:space-between; align-items:center; margin-bottom:8px; padding-bottom:7px; border-bottom:1px solid #523818; gap:6px; }
        .vu-wrap { height:6px; background:#1c0a0e; border:1px solid #523818; margin-bottom:8px; overflow:hidden; }
        .vu-fill { height:100%; width:0%; background:linear-gradient(90deg, #ffb703, #ef233c); transition:width 60ms linear; }
        .modes { display:grid; grid-template-columns:repeat(4,1fr); gap:4px; margin-bottom:8px; }
        .modes button, .sfx button, .act-btn { background:#1c140b; border:1px solid #523818; color:#fff; padding:6px 3px; font-size:9px; font-weight:800; cursor:pointer; }
        .modes button.active, .act-btn.on { border-color:#f59e0b; background:rgba(239,35,60,0.28); color:#fde047; }
        .sfx { display:grid; grid-template-columns:repeat(4,1fr); gap:4px; margin:8px 0 0; }
        .grid { display:grid; grid-template-columns:1fr 1fr; gap:5px; }
        .row { background:#1c140b; border:1px solid #523818; padding:6px; }
        .row.full { grid-column:1 / -1; }
        .row-top { display:flex; justify-content:space-between; font-size:9px; font-weight:700; margin-bottom:3px; }
        input[type=range] { width:100%; accent-color:#f59e0b; }
      </style>
      <button class="fab" id="openBtn">👑 MENTALS MIC</button>
      <div class="panel" id="panel">
        <div class="head">
          <strong style="font-size:12px;color:#fff">👑 MENTALS · MIC DSP</strong>
          <div style="display:flex;gap:4px">
            <button class="act-btn" id="muteBtn">MUTE</button>
            <button class="act-btn" id="bypassBtn">DSP ON</button>
            <button id="closeBtn" style="background:none;border:1px solid #523818;color:#ccc;padding:2px 7px;cursor:pointer;font-size:10px">X</button>
          </div>
        </div>
        <div class="vu-wrap"><div class="vu-fill" id="vuBar"></div></div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:4px;margin-bottom:7px">
          <button class="act-btn" id="overdriveBtn">⚡ +6dB BOOST: ON</button>
          <button class="act-btn" id="antiDuckBtn">🛡️ NO-DUCK: ON</button>
        </div>
        <div class="modes">
          <button data-p="dragonRoar">🐉 DRAGON</button>
          <button data-p="demonBeast">👹 DEMON</button>
          <button data-p="radioStudio">🎙️ RADIO</button>
          <button data-p="shadowStealth">🌑 SHADOW</button>
        </div>
        <div class="grid" id="sliders"></div>
        <div class="sfx">
          <button data-sfx="roar">🐉 ROAR</button>
          <button data-sfx="boom">💥 BOOM</button>
          <button data-sfx="thunder">⚡ THUND</button>
          <button id="loadSfxBtn">+ MP3</button>
        </div>
        <input type="file" id="sfxFile" accept="audio/*" hidden />
      </div>
    `;
    const openBtn = shadow.getElementById('openBtn');
    const panel = shadow.getElementById('panel');
    const closeBtn = shadow.getElementById('closeBtn');
    const muteBtn = shadow.getElementById('muteBtn');
    const bypassBtn = shadow.getElementById('bypassBtn');
    const overdriveBtn = shadow.getElementById('overdriveBtn');
    const antiDuckBtn = shadow.getElementById('antiDuckBtn');
    const vuBar = shadow.getElementById('vuBar');
    const sliders = shadow.getElementById('sliders');
    const sfxFile = shadow.getElementById('sfxFile');

    const defs = [
      ['micGain','DRAGON DRIVE',0,1000,true],
      ['subBass','SUB-BASS BEAST',0,100,false],
      ['bass','BASS PUNCH',0,100,false],
      ['voiceClarity','VOCAL FANG',0,100,false],
      ['treble','TREBLE EDGE',0,100,false],
      ['loudness','LOUDNESS MAX',0,100,false],
      ['noiseControl','NOISE GATE',0,100,false],
      ['echo','DRAGON ECHO',0,100,false]
    ];

    function saveAndSync() {
      try { localStorage.setItem(STORAGE_KEY, JSON.stringify(settings)); } catch {}
      activeEngines.forEach((e) => applySettings(e, settings));
    }

    function syncTopButtons() {
      muteBtn.textContent = isMuted ? 'UNMUTE' : 'MUTE';
      muteBtn.classList.toggle('on', isMuted);
      bypassBtn.textContent = isBypassed ? 'BYPASSED' : 'DSP ON';
      bypassBtn.classList.toggle('on', !isBypassed);
      const od = settings.overdrive !== false;
      overdriveBtn.textContent = od ? '⚡ +6dB BOOST: ON' : '⚡ +6dB BOOST: OFF';
      overdriveBtn.classList.toggle('on', od);
      const nd = settings.antiDuck !== false;
      antiDuckBtn.textContent = nd ? '🛡️ NO-DUCK: ON' : '🛡️ AEC SAFE';
      antiDuckBtn.classList.toggle('on', nd);
      openBtn.textContent = isMuted ? '🔇 MUTED' : '👑 MENTALS MIC';
    }

    function render() {
      sliders.innerHTML = '';
      defs.forEach(([k, lbl, min, max, isFull]) => {
        const d = document.createElement('div'); d.className = isFull ? 'row full' : 'row';
        d.innerHTML = `<div class="row-top"><span>${lbl}</span><span id="v-${k}" style="color:#fde047">${settings[k] || 0}%</span></div>`;
        const inp = document.createElement('input'); inp.type = 'range'; inp.min = min; inp.max = max; inp.value = settings[k] || 0;
        inp.addEventListener('input', (ev) => { settings[k] = Number(ev.target.value); shadow.getElementById('v-' + k).textContent = settings[k] + '%'; saveAndSync(); });
        d.appendChild(inp); sliders.appendChild(d);
      });
    }

    shadow.querySelectorAll('[data-p]').forEach((b) => b.addEventListener('click', () => {
      const p = b.getAttribute('data-p');
      if (PRESETS[p]) {
        isBypassed = false;
        settings = { ...PRESETS[p] };
        render(); saveAndSync(); syncTopButtons();
      }
    }));

    shadow.querySelectorAll('[data-sfx]').forEach((b) => b.addEventListener('click', () => {
      triggerSfx(b.getAttribute('data-sfx'));
    }));

    shadow.getElementById('loadSfxBtn').addEventListener('click', () => sfxFile.click());
    sfxFile.addEventListener('change', async (ev) => {
      const f = ev.target.files && ev.target.files[0];
      if (!f) return;
      try {
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        const c = new AudioCtx();
        customAudioBuffer = await c.decodeAudioData(await f.arrayBuffer());
        c.close().catch(() => {});
        triggerSfx('custom');
        showMiniToast('🎵 CUSTOM MP3 LOADED & FIRED');
      } catch {
        showMiniToast('⚠️ AUDIO LOAD FAILED');
      }
    });

    muteBtn.addEventListener('click', () => window.__mentalsToggleMute());
    bypassBtn.addEventListener('click', () => window.__mentalsToggleBypass());
    overdriveBtn.addEventListener('click', () => {
      settings.overdrive = settings.overdrive === false;
      saveAndSync();
      syncTopButtons();
      showMiniToast(settings.overdrive ? '⚡ +6dB OVERDRIVE ON!' : 'Standard Drive');
    });
    antiDuckBtn.addEventListener('click', () => {
      settings.antiDuck = settings.antiDuck === false;
      saveAndSync();
      syncTopButtons();
      showMiniToast(settings.antiDuck ? '🛡️ NO-DUCK RAW MIC (Rejoin VC to apply)' : 'AEC Echo-Safe Mode');
    });
    window.addEventListener('mentals-dsp-state', syncTopButtons);
    window.__mentalsOnPip = (inPip) => {
      host.style.display = inPip ? 'none' : 'block';
      if (window.__mentalsOnPipChanger) window.__mentalsOnPipChanger(inPip);
    };

    let vuTimer = 0;
    const sampleBuf = new Uint8Array(64);
    function updateVu() {
      if (!panel.classList.contains('open')) { vuTimer = 0; return; }
      let peak = 0;
      activeEngines.forEach((e) => {
        if (e.analyser) {
          e.analyser.getByteTimeDomainData(sampleBuf);
          for (let i = 0; i < sampleBuf.length; i++) {
            const v = Math.abs((sampleBuf[i] - 128) / 128);
            if (v > peak) peak = v;
          }
        }
      });
      vuBar.style.width = Math.min(100, Math.round(peak * 145)) + '%';
      vuTimer = window.setTimeout(updateVu, 75);
    }

    let dragActive = false, dragMoved = false, sx = 0, sy = 0, sl = 0, st = 0;
    function beginDrag(cx, cy) {
      const r = host.getBoundingClientRect();
      dragActive = true; dragMoved = false; sx = cx; sy = cy; sl = r.left; st = r.top;
    }
    function onDragMove(cx, cy) {
      if (!dragActive) return;
      const dx = cx - sx, dy = cy - sy;
      if (Math.abs(dx) > 6 || Math.abs(dy) > 6) dragMoved = true;
      if (!dragMoved) return;
      const maxL = Math.max(8, window.innerWidth - host.offsetWidth - 8);
      const maxT = Math.max(8, window.innerHeight - host.offsetHeight - 8);
      host.style.right = 'auto'; host.style.bottom = 'auto';
      host.style.left = Math.max(8, Math.min(maxL, sl + dx)) + 'px';
      host.style.top = Math.max(8, Math.min(maxT, st + dy));
    }
    function finishDrag() {
      if (!dragActive) return;
      dragActive = false;
      if (dragMoved) {
        try { localStorage.setItem(POS_KEY, JSON.stringify({ left: parseFloat(host.style.left) || 8, top: parseFloat(host.style.top) || 92 })); } catch {}
      }
    }
    openBtn.addEventListener('touchstart', (e) => { if (e.touches[0]) beginDrag(e.touches[0].clientX, e.touches[0].clientY); }, { passive: true });
    window.addEventListener('touchmove', (e) => { if (dragActive && e.touches[0]) onDragMove(e.touches[0].clientX, e.touches[0].clientY); }, { passive: true });
    window.addEventListener('touchend', finishDrag);
    openBtn.addEventListener('mousedown', (e) => beginDrag(e.clientX, e.clientY));
    window.addEventListener('mousemove', (e) => onDragMove(e.clientX, e.clientY));
    window.addEventListener('mouseup', finishDrag);
    window.addEventListener('resize', () => {
      if (host.style.left) {
        const maxL = Math.max(8, window.innerWidth - host.offsetWidth - 8);
        const maxT = Math.max(8, window.innerHeight - host.offsetHeight - 8);
        host.style.left = Math.max(8, Math.min(maxL, parseFloat(host.style.left) || 8)) + 'px';
        host.style.top = Math.max(8, Math.min(maxT, parseFloat(host.style.top) || 92)) + 'px';
      }
    });

    openBtn.addEventListener('click', () => {
      if (dragMoved) { dragMoved = false; return; }
      if (window.__mentalsCloseVoiceChanger) window.__mentalsCloseVoiceChanger();
      panel.classList.add('open'); openBtn.style.display = 'none'; updateVu();
    });
    closeBtn.addEventListener('click', () => { panel.classList.remove('open'); openBtn.style.display = 'inline-block'; clearTimeout(vuTimer); });
    window.__mentalsCloseMicMenu = () => { panel.classList.remove('open'); openBtn.style.display = 'inline-block'; clearTimeout(vuTimer); };

    render();
    syncTopButtons();
    document.documentElement.appendChild(host);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mountUi); else mountUi();
})();
