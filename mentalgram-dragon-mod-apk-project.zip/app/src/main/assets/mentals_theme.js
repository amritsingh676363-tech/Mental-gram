// mentals_theme.js - Mentalgram Dangerous Dragon Dark Theme & Red Flame MENTALSGRAM Header (Web K & Web A)
(() => {
  if (window.__mentalgramThemeInstalled) return;
  window.__mentalgramThemeInstalled = true;

  const STYLE_ID = 'mentalgram-dragon-theme-css';
  const CSS_CONTENT = `
    :root, html, html.theme-dark, html.night, body, .theme-dark, .night {
      --color-background: #060304 !important;
      --color-background-secondary: #0c0406 !important;
      --color-background-compact-menu: #130609 !important;
      --color-background-compact-menu-hover: rgba(239, 35, 60, 0.22) !important;
      --color-background-selected: rgba(239, 35, 60, 0.22) !important;
      --color-chat-hover: rgba(239, 35, 60, 0.14) !important;
      --color-chat-active: linear-gradient(90deg, rgba(239, 35, 60, 0.34), rgba(120, 8, 24, 0.22)) !important;
      --color-primary: #ef233c !important;
      --color-primary-shade: #b80c24 !important;
      --color-primary-opacity: rgba(239, 35, 60, 0.18) !important;
      --color-links: #ff4d6d !important;
      --color-borders: rgba(239, 35, 60, 0.28) !important;
      --color-borders-input: rgba(239, 35, 60, 0.42) !important;
      --color-text: #f8fafc !important;
      --color-text-secondary: #c9969e !important;
      --color-text-meta: #b37b85 !important;
      --color-message-outgoing: #2a0710 !important;
      --color-message-incoming: #110609 !important;
      --color-reply-own: rgba(255, 183, 3, 0.16) !important;
      --color-green: #ffb703 !important;
      --color-error: #ff1e42 !important;
      --surface-color: #090305 !important;
      --background-color: #060304 !important;
      --primary-color: #ef233c !important;
      --light-primary-color: rgba(239, 35, 60, 0.18) !important;
      --message-out-background-color: #2a0710 !important;
      --message-background-color: #120609 !important;
      --border-color: rgba(239, 35, 60, 0.28) !important;
      --primary-text-color: #f8fafc !important;
      --secondary-text-color: #c9969e !important;
    }

    body, #Main, #LeftColumn, #MiddleColumn, #RightColumn,
    #page-chats, #column-left, #column-center, #column-right, .tabs-container {
      background-color: #060304 !important;
      color: #f8fafc !important;
    }

    .LeftMainHeader, .MiddleHeader, .GroupCallHeader, .CallHeader,
    .sidebar-header, .topbar, .chat-info-container, .group-call-header {
      background: linear-gradient(180deg, #160509 0%, #090305 100%) !important;
      border-bottom: 1px solid rgba(239, 35, 60, 0.38) !important;
      box-shadow: 0 4px 18px rgba(239, 35, 60, 0.16) !important;
    }

    .messages-layout, .MessageList, .bubbles, .chat-background {
      background-color: #050203 !important;
      background-image: none !important;
    }

    /* Reduce Android WebView GPU overdraw & chat-open lag */
    .bubble, .Message, .topbar, .MiddleHeader, .backdrop, .Menu {
      backdrop-filter: none !important;
      -webkit-backdrop-filter: none !important;
    }

    .ListItem.selected .ListItem-button, .chat-item-clickable.selected, .chatlist-chat.active {
      background: rgba(239, 35, 60, 0.24) !important;
      border-left: 3px solid #ff2a4b !important;
    }

    .Badge, .unread-count, .dialog-subtitle-badge {
      background: #ef233c !important;
      color: #ffffff !important;
    }

    .Composer, .message-input-wrapper, .input-message-container, .new-message-wrapper {
      background: #110508 !important;
      border: 1px solid rgba(239, 35, 60, 0.35) !important;
    }

    .Button.primary, button.primary, .send.main-button, .btn-primary, .btn-send {
      background: linear-gradient(135deg, #ef233c, #9e001c) !important;
      color: #ffffff !important;
    }

    /* Turbo Slow-Net Mode */
    html.mental-turbo-lite *, html.mental-turbo-lite *::before, html.mental-turbo-lite *::after {
      animation: none !important;
      transition: none !important;
    }
    html.mental-turbo-lite .AnimatedSticker canvas,
    html.mental-turbo-lite .rlottie-wrapper canvas,
    html.mental-turbo-lite video.media-sticker {
      opacity: 0.35 !important;
    }

    /* 1-Tap Privacy Chat Blur */
    html.mental-privacy-blur .bubbles,
    html.mental-privacy-blur .MessageList,
    html.mental-privacy-blur .chatlist-chat,
    html.mental-privacy-blur .ListItem.Chat {
      filter: blur(10px) !important;
      transition: filter 120ms ease !important;
    }

    /* Anti-Delete Inline Badge */
    .mental-deleted-tag {
      display: inline-block;
      margin-left: 6px;
      padding: 1px 6px;
      font-size: 9px;
      font-weight: 900;
      font-family: monospace;
      color: #ffffff;
      background: #b80c24;
      border: 1px solid #ffb703;
      letter-spacing: 0.06em;
    }
    .mental-deleted-ghost {
      opacity: 0.88 !important;
      border-left: 3px solid #ff2a4b !important;
      background: rgba(184, 12, 36, 0.18) !important;
      padding: 4px 8px !important;
      margin: 4px 8px !important;
      border-radius: 8px !important;
    }

    .mentalgram-brand-bar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 6px;
      padding: 6px 10px;
      background: linear-gradient(90deg, #160408 0%, #24060c 50%, #120407 100%);
      border-bottom: 1px solid rgba(239, 35, 60, 0.45);
      user-select: none;
      z-index: 50;
      flex-shrink: 0;
    }

    .mentalgram-flame-text {
      font-family: "Cinzel Decorative", "Impact", "Arial Black", "Trebuchet MS", sans-serif;
      font-weight: 900;
      font-style: italic;
      font-size: 15px;
      letter-spacing: 0.1em;
      text-transform: uppercase;
      background: linear-gradient(180deg, #fff3b0 0%, #ffb703 25%, #ff2a4b 62%, #8f0016 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      text-shadow: 0 0 8px rgba(255, 28, 60, 0.65);
      line-height: 1.1;
      white-space: nowrap;
    }

    .mentalgram-bar-actions {
      display: flex;
      align-items: center;
      gap: 4px;
      flex-shrink: 0;
    }

    .mentalgram-switch-btn {
      font-family: monospace;
      font-size: 9px;
      font-weight: 800;
      letter-spacing: 0.05em;
      color: #ffb703;
      border: 1px solid rgba(239, 35, 60, 0.65);
      background: rgba(239, 35, 60, 0.18);
      padding: 3px 6px;
      cursor: pointer;
      white-space: nowrap;
      clip-path: polygon(4px 0, 100% 0, calc(100% - 4px) 100%, 0 100%);
    }

    .mentalgram-power-btn {
      font-family: monospace;
      font-size: 9px;
      font-weight: 900;
      letter-spacing: 0.05em;
      color: #ffffff;
      border: 1px solid #ffb703;
      background: linear-gradient(135deg, #ef233c, #9e001c);
      padding: 3px 7px;
      cursor: pointer;
      white-space: nowrap;
      clip-path: polygon(4px 0, 100% 0, calc(100% - 4px) 100%, 0 100%);
    }
  `;

  function ensureStyle() {
    if (!document.head) return;
    if (!document.documentElement.classList.contains('theme-dark')) {
      document.documentElement.classList.add('theme-dark', 'night');
    }
    if (!document.getElementById(STYLE_ID)) {
      const style = document.createElement('style');
      style.id = STYLE_ID;
      style.textContent = CSS_CONTENT;
      document.head.appendChild(style);
    }
  }

  let headingScanned = false;
  function applyMentalgramBranding() {
    ensureStyle();

    if (document.title !== '🔥 MENTALSGRAM') {
      document.title = '🔥 MENTALSGRAM';
    }

    const targetCol =
      document.getElementById('LeftColumn') ||
      document.getElementById('column-left') ||
      document.querySelector('.auth-pages') ||
      document.body;

    if (targetCol && !document.getElementById('mentalgram-top-strip')) {
      const isWebK = location.pathname.startsWith('/k');
      const slot = window.MentalBridge && window.MentalBridge.getAccountSlot ? window.MentalBridge.getAccountSlot() : 1;
      const strip = document.createElement('div');
      strip.id = 'mentalgram-top-strip';
      strip.className = 'mentalgram-brand-bar';
      strip.innerHTML =
        '<span class="mentalgram-flame-text">🔥 MENTALSGRAM' + (slot > 1 ? ' #' + slot : '') + '</span>' +
        '<div class="mentalgram-bar-actions">' +
        '<button type="button" id="mentalgramBlurBtn" class="mentalgram-switch-btn" title="1-Tap Blur">👁️</button>' +
        '<button type="button" id="mentalgramPowerBtn" class="mentalgram-power-btn">⚡ POWER</button>' +
        '<button type="button" id="mentalgramModeSwitch" class="mentalgram-switch-btn">' +
        (isWebK ? 'WEB K ⇄' : 'WEB A ⇄') +
        '</button>' +
        '</div>';

      if (targetCol === document.body) {
        strip.style.position = 'fixed';
        strip.style.top = '0';
        strip.style.left = '0';
        strip.style.right = '0';
      }
      targetCol.insertBefore(strip, targetCol.firstChild);

      const blurBtn = document.getElementById('mentalgramBlurBtn');
      if (blurBtn) {
        blurBtn.addEventListener('click', () => {
          const on = document.documentElement.classList.toggle('mental-privacy-blur');
          blurBtn.textContent = on ? '🙈' : '👁️';
        });
      }

      const pBtn = document.getElementById('mentalgramPowerBtn');
      if (pBtn) {
        pBtn.addEventListener('click', () => {
          if (window.__mentalsOpenPowerHub) window.__mentalsOpenPowerHub();
        });
      }

      const btn = document.getElementById('mentalgramModeSwitch');
      if (btn) {
        btn.addEventListener('click', () => {
          location.href = isWebK ? 'https://web.telegram.org/a/' : 'https://web.telegram.org/k/';
        });
      }
    }

    const isLoggedInUi = !!(document.getElementById('LeftColumn') || document.getElementById('column-left'));
    if (isLoggedInUi && document.getElementById('mentalgram-top-strip')) {
      headingScanned = true;
      observer.disconnect();
      return;
    }

    if (!headingScanned) {
      const candidates = document.querySelectorAll('h1, h2, h3, h4, .title, .auth-form h1, .HeaderTitle, .sign-logo + h4');
      candidates.forEach((el) => {
        if (el.dataset.mentalgramDone) return;
        const txt = (el.textContent || '').trim();
        if (/^(sign in to )?telegram(\s+web)?$/i.test(txt)) {
          el.dataset.mentalgramDone = '1';
          el.innerHTML = '<span class="mentalgram-flame-text">🔥 MENTALSGRAM</span>';
          headingScanned = true;
        }
      });
    }
  }

  let throttleTimer = 0;
  const observer = new MutationObserver(() => {
    if (document.getElementById('mentalgram-top-strip') && headingScanned) {
      observer.disconnect();
      return;
    }
    if (throttleTimer) return;
    throttleTimer = window.setTimeout(() => {
      throttleTimer = 0;
      applyMentalgramBranding();
    }, 350);
  });
  if (document.documentElement) {
    observer.observe(document.documentElement, { childList: true, subtree: true });
  }
  window.setInterval(() => {
    if (!document.getElementById('mentalgram-top-strip')) applyMentalgramBranding();
  }, 4000);
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', applyMentalgramBranding);
  } else {
    applyMentalgramBranding();
  }
})();
