// mentals_powers.js - Mentalgram v3.2 God-Mode Power Hub & Chat Automation Engine
(() => {
  if (window.__mentalsPowersInstalled) return;
  window.__mentalsPowersInstalled = true;

  const CFG_KEY = 'mentals_power_hub_cfg_v33';
  const REPLIED_KEY = 'mentals_afk_replied_map_v32';

  let cfg = {
    vcLock: false,
    volMode: 'OFF',
    audioRoute: 'AUTO',
    turboLite: true,
    afkEnabled: false,
    afkTemplate: 'Dear {name}, Thank you for msg me, my boss is busy now.',
    afkCooldownMin: 15,
    afkDelaySec: 3,
    afkCount: 0,
    kwReplyEnabled: false,
    kwScope: 'DM',
    kwRules: 'vc = 👑 VC aa rha hun 2 min me!\nlink = 🔥 Join @Mental_stuff_gc\nhi = Kya haal hai {name} 🔥',
    scriptLines: '👑 ENTRY ON HAI\n🔥 AAJAO VC ME SAB\n⚡ MENTALS ON TOP',
    scriptDelaySec: 3,
    radarEnabled: false,
    radarKeywords: 'VC, join, @',
    antiDelete: true,
    ghostMode: false,
    screenSecure: false,
    templates: [
      '👑 AA RHA HUN VC ME',
      '🔥 BOSS BUSY HAI ABHI',
      '⚡ 2 MIN ME JOIN KAR RHA HUN'
    ]
  };

  try {
    const rawV33 = localStorage.getItem(CFG_KEY);
    const rawOld = localStorage.getItem('mentals_power_hub_cfg_v32') || localStorage.getItem('mentals_power_hub_cfg_v30');
    if (rawV33) {
      cfg = { ...cfg, ...JSON.parse(rawV33) };
    } else if (rawOld) {
      cfg = { ...cfg, ...JSON.parse(rawOld), turboLite: true };
    }
  } catch {}

  let repliedMap = {};
  try {
    const r = localStorage.getItem(REPLIED_KEY);
    if (r) repliedMap = JSON.parse(r);
  } catch {}

  function saveCfg() {
    try { localStorage.setItem(CFG_KEY, JSON.stringify(cfg)); } catch {}
  }

  function saveReplied() {
    try { localStorage.setItem(REPLIED_KEY, JSON.stringify(repliedMap)); } catch {}
  }

  function applyTurboClass() {
    if (cfg.turboLite) document.documentElement.classList.add('mental-turbo-lite');
    else document.documentElement.classList.remove('mental-turbo-lite');
  }
  applyTurboClass();

  // Pause background DOM scans during chat scrolling or Voice Chat call connection
  let scrollPauseUntil = 0;
  window.addEventListener('scroll', () => {
    scrollPauseUntil = Date.now() + 1800;
  }, { passive: true, capture: true });
  document.addEventListener('click', (ev) => {
    const t = ev.target;
    if (t && t.closest && t.closest('.btn-call, .call-btn, .GroupCallHeader, [class*="call"]')) {
      scrollPauseUntil = Date.now() + 3000;
    }
  }, { passive: true, capture: true });

  function toast(msg) {
    let el = document.getElementById('mentals-power-toast');
    if (!el) {
      el = document.createElement('div');
      el.id = 'mentals-power-toast';
      el.style.cssText = 'position:fixed;top:48px;left:50%;transform:translateX(-50%);background:#140508;color:#ffb703;border:1px solid #ef233c;padding:7px 14px;font-size:11px;font-weight:800;font-family:monospace;z-index:2147483647;box-shadow:0 4px 18px rgba(239,35,60,0.5);max-width:88vw;text-align:center;pointer-events:none;';
      document.documentElement.appendChild(el);
    }
    el.textContent = msg;
    el.style.display = 'block';
    clearTimeout(el._t);
    el._t = setTimeout(() => { el.style.display = 'none'; }, 2400);
  }

  // ===== GHOST MODE: HOOK WORKER POSTMESSAGE TO DROP TYPING / RECORDING ACTIONS =====
  if (window.Worker && !window.__mentalsWorkerPatched) {
    window.__mentalsWorkerPatched = true;
    const origPost = Worker.prototype.postMessage;
    Worker.prototype.postMessage = function (message, transfer) {
      if (cfg.ghostMode && message && typeof message === 'object') {
        try {
          const mName = String(message.method || message.name || message.type || '');
          const argsStr = message.args ? JSON.stringify(message.args) : '';
          if (/setTyping|sendAction/i.test(mName) || /setTyping|sendMessageTypingAction|sendMessageRecordAudioAction/i.test(argsStr)) {
            return;
          }
        } catch {}
      }
      return origPost.apply(this, arguments);
    };
  }

  // ===== DUAL-SIDE VC RECORDER (CAPTURES REMOTE RTCPeerConnection + LOCAL MIC) =====
  const remoteStreams = new Set();
  if (window.RTCPeerConnection && !window.__mentalsRtcHooked) {
    window.__mentalsRtcHooked = true;
    const OrigPeer = window.RTCPeerConnection;
    window.RTCPeerConnection = function (...args) {
      const pc = new OrigPeer(...args);
      pc.addEventListener('track', (ev) => {
        if (ev.track && ev.track.kind === 'audio') {
          const s = (ev.streams && ev.streams[0]) ? ev.streams[0] : new MediaStream([ev.track]);
          remoteStreams.add(s);
          ev.track.addEventListener('ended', () => remoteStreams.delete(s));
        }
      });
      return pc;
    };
    window.RTCPeerConnection.prototype = OrigPeer.prototype;
  }

  let recState = { active: false, recorder: null, ctx: null, chunks: [] };

  function toggleVcRecording(onUpdate) {
    if (recState.active && recState.recorder) {
      try { recState.recorder.stop(); } catch {}
      return;
    }

    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      const ctx = new AudioCtx();
      const dest = ctx.createMediaStreamDestination();
      let attached = 0;

      const addedIds = new Set();
      const micStream = window.__mentalsGetMicStream ? window.__mentalsGetMicStream() : null;
      if (micStream && micStream.getAudioTracks().length > 0) {
        try {
          ctx.createMediaStreamSource(micStream).connect(dest);
          addedIds.add(micStream.id);
          attached++;
        } catch {}
      }

      remoteStreams.forEach((rs) => {
        if (!addedIds.has(rs.id) && rs.getAudioTracks().some((t) => t.readyState === 'live')) {
          try {
            ctx.createMediaStreamSource(rs).connect(dest);
            addedIds.add(rs.id);
            attached++;
          } catch {}
        }
      });

      document.querySelectorAll('audio, video').forEach((el) => {
        const s = el.srcObject;
        if (s && !addedIds.has(s.id) && s.getAudioTracks && s.getAudioTracks().some((t) => t.readyState === 'live')) {
          try {
            ctx.createMediaStreamSource(s).connect(dest);
            addedIds.add(s.id);
            attached++;
          } catch {}
        }
      });

      if (attached === 0) {
        ctx.close().catch(() => {});
        toast('⚠️ Pehle Voice Chat ya Call join karein');
        return;
      }

      const chunks = [];
      const mr = new MediaRecorder(dest.stream);
      mr.ondataavailable = (e) => { if (e.data && e.data.size > 0) chunks.push(e.data); };
      mr.onstop = () => {
        recState.active = false;
        ctx.close().catch(() => {});
        const blob = new Blob(chunks, { type: mr.mimeType || 'audio/webm' });
        const reader = new FileReader();
        reader.onloadend = () => {
          const fname = 'Mentalgram_VC_' + Date.now() + '.webm';
          if (window.MentalBridge && window.MentalBridge.saveRecording) {
            window.MentalBridge.saveRecording(String(reader.result || ''), fname);
          } else {
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a'); a.href = url; a.download = fname; a.click();
            URL.revokeObjectURL(url);
          }
        };
        reader.readAsDataURL(blob);
        if (onUpdate) onUpdate();
      };

      mr.start(500);
      recState = { active: true, recorder: mr, ctx, chunks };
      toast('🔴 VC Recording Started...');
      if (onUpdate) onUpdate();
    } catch {
      toast('⚠️ Recording start nahi ho payi');
    }
  }

  // ===== SCREEN RECORDER + DUAL VOICE (ROAR MIC + REMOTE CALL AUDIO -> MP4) =====
  let screenRec = {
    active: false,
    ctx: null,
    proc: null,
    silentGain: null,
    attachedIds: new Set(),
    extraMicStream: null,
    pollId: 0,
    timerId: 0,
    startedAt: 0,
    pcmBuf: new Int16Array(0),
    sampleRate: 48000,
    onUi: null
  };

  function int16ToBase64(arr) {
    const bytes = new Uint8Array(arr.buffer, arr.byteOffset, arr.byteLength);
    let bin = '';
    const step = 0x8000;
    for (let i = 0; i < bytes.length; i += step) {
      bin += String.fromCharCode.apply(null, bytes.subarray(i, i + step));
    }
    return btoa(bin);
  }

  function flushScreenPcm() {
    if (!screenRec.pcmBuf || screenRec.pcmBuf.length === 0) return;
    if (window.MentalBridge && window.MentalBridge.appendScreenRecPcm) {
      window.MentalBridge.appendScreenRecPcm(int16ToBase64(screenRec.pcmBuf));
    }
    screenRec.pcmBuf = new Int16Array(0);
  }

  function attachLiveStreamsToScreenRec() {
    if (!screenRec.active || !screenRec.ctx || !screenRec.proc) return;
    const { ctx, proc, attachedIds } = screenRec;

    const tryAttach = (stream, keyPrefix) => {
      if (!stream || !stream.getAudioTracks) return;
      const tracks = stream.getAudioTracks();
      if (!tracks.some((t) => t.readyState === 'live')) return;
      const key = keyPrefix + ':' + (stream.id || tracks[0].id);
      if (attachedIds.has(key)) return;
      try {
        ctx.createMediaStreamSource(stream).connect(proc);
        attachedIds.add(key);
      } catch {}
    };

    const micStream = window.__mentalsGetMicStream ? window.__mentalsGetMicStream() : null;
    tryAttach(micStream, 'mic');
    if (screenRec.extraMicStream) tryAttach(screenRec.extraMicStream, 'mic');

    remoteStreams.forEach((rs) => tryAttach(rs, 'rtc'));
    document.querySelectorAll('audio, video').forEach((el) => {
      if (el.srcObject) tryAttach(el.srcObject, 'dom');
    });
  }

  function updateScreenRecPill() {
    let pill = document.getElementById('mentals-srec-pill');
    if (!screenRec.active) {
      if (pill) pill.remove();
      return;
    }
    if (!pill) {
      pill = document.createElement('button');
      pill.id = 'mentals-srec-pill';
      pill.type = 'button';
      pill.style.cssText = 'position:fixed;top:44px;right:10px;z-index:2147483646;background:#b80c24;color:#fff;border:1px solid #ffb703;padding:5px 10px;font-size:10px;font-weight:900;font-family:monospace;box-shadow:0 0 14px rgba(239,35,60,0.65);cursor:pointer;';
      pill.addEventListener('click', () => window.__mentalsStopScreenRec && window.__mentalsStopScreenRec());
      document.documentElement.appendChild(pill);
    }
    const sec = Math.max(0, Math.floor((Date.now() - screenRec.startedAt) / 1000));
    const mm = String(Math.floor(sec / 60)).padStart(2, '0');
    const ss = String(sec % 60).padStart(2, '0');
    pill.textContent = '⏹️ REC ' + mm + ':' + ss;
  }

  window.__mentalsOnScreenRecStarted = async () => {
    if (screenRec.active) return;
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      const ctx = new AudioCtx();
      if (ctx.state === 'suspended') await ctx.resume();

      const proc = ctx.createScriptProcessor(4096, 1, 1);
      const silentGain = ctx.createGain();
      silentGain.gain.value = 0;
      proc.connect(silentGain);
      silentGain.connect(ctx.destination);

      let extraMic = null;
      const existingMic = window.__mentalsGetMicStream ? window.__mentalsGetMicStream() : null;
      if (!existingMic && navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        try {
          extraMic = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
        } catch {}
      }

      screenRec = {
        active: true,
        ctx,
        proc,
        silentGain,
        attachedIds: new Set(),
        extraMicStream: extraMic,
        pollId: 0,
        timerId: 0,
        startedAt: Date.now(),
        pcmBuf: new Int16Array(0),
        sampleRate: ctx.sampleRate || 48000,
        onUi: screenRec.onUi
      };

      proc.onaudioprocess = (ev) => {
        if (!screenRec.active) return;
        const input = ev.inputBuffer.getChannelData(0);
        const next = new Int16Array(screenRec.pcmBuf.length + input.length);
        next.set(screenRec.pcmBuf, 0);
        const offset = screenRec.pcmBuf.length;
        for (let i = 0; i < input.length; i++) {
          let s = input[i];
          if (s > 1) s = 1;
          else if (s < -1) s = -1;
          next[offset + i] = s < 0 ? (s * 32768) | 0 : (s * 32767) | 0;
        }
        screenRec.pcmBuf = next;
        if (screenRec.pcmBuf.length >= 16384) {
          flushScreenPcm();
        }
      };

      attachLiveStreamsToScreenRec();
      screenRec.pollId = window.setInterval(attachLiveStreamsToScreenRec, 1400);
      screenRec.timerId = window.setInterval(updateScreenRecPill, 1000);
      updateScreenRecPill();
      toast('🎬 Screen + Roar & Call Voice Rec ON!');
      if (screenRec.onUi) screenRec.onUi();
    } catch {
      toast('⚠️ Audio mix failed, video recording active');
    }
  };

  window.__mentalsStopScreenRec = () => {
    if (!screenRec.active) {
      if (window.MentalBridge && window.MentalBridge.stopScreenRec) window.MentalBridge.stopScreenRec(48000);
      return;
    }
    const sr = screenRec.sampleRate || 48000;
    screenRec.active = false;
    clearInterval(screenRec.pollId);
    clearInterval(screenRec.timerId);
    flushScreenPcm();
    try { if (screenRec.proc) screenRec.proc.disconnect(); } catch {}
    try { if (screenRec.silentGain) screenRec.silentGain.disconnect(); } catch {}
    try { if (screenRec.ctx && screenRec.ctx.state !== 'closed') screenRec.ctx.close(); } catch {}
    if (screenRec.extraMicStream) {
      try { screenRec.extraMicStream.getTracks().forEach((t) => t.stop()); } catch {}
      screenRec.extraMicStream = null;
    }
    updateScreenRecPill();
    toast('⏳ Saving Video + Dual Voice to Gallery...');
    if (window.MentalBridge && window.MentalBridge.stopScreenRec) {
      window.MentalBridge.stopScreenRec(sr);
    }
    if (screenRec.onUi) screenRec.onUi();
  };

  // ===== ANTI-DELETE CATCHER (LOCAL MESSAGE VAULT - ZERO REFLOW) =====
  const msgCache = new Map();
  const deletedLogs = [];
  let antiHash = location.hash;
  let antiPauseUntil = 0;

  function scanAndProtectMessages() {
    if (!cfg.antiDelete || document.hidden) return;
    const now = Date.now();
    if (now < scrollPauseUntil || now < antiPauseUntil) return;
    if (location.hash !== antiHash) {
      antiHash = location.hash;
      msgCache.clear();
      antiPauseUntil = now + 1200;
      return;
    }

    const container = document.querySelector('.bubbles-inner, .messages-container');
    if (!container) return;
    const nodes = container.querySelectorAll('.bubble[data-mid], .Message[data-message-id]');
    if (!nodes.length) return;

    const currentIds = new Set();
    const startIdx = Math.max(0, nodes.length - 24);
    for (let i = startIdx; i < nodes.length; i++) {
      const n = nodes[i];
      if (n.dataset.mentalDeletedRestore) continue;
      const mid = n.getAttribute('data-mid') || n.getAttribute('data-message-id');
      if (!mid) continue;
      currentIds.add(mid);

      if (!msgCache.has(mid)) {
        const textEl = n.querySelector('.message, .text-content, .translatable-message');
        const txt = textEl ? (textEl.textContent || '').trim() : '';
        if (txt) {
          msgCache.set(mid, { mid, text: txt, chat: getOpenChatTitle(), time: new Date().toLocaleTimeString(), elHtml: txt.slice(0, 180) });
          if (msgCache.size > 160) {
            const firstKey = msgCache.keys().next().value;
            msgCache.delete(firstKey);
          }
        }
      }
    }

    // Check if an earlier mid in the middle of the visible list suddenly disappeared
    const idsArr = Array.from(currentIds).map((x) => Number(x)).filter((n) => !Number.isNaN(n));
    if (idsArr.length < 3) return;
    const minId = Math.min(...idsArr);
    const maxId = Math.max(...idsArr);

    msgCache.forEach((entry, key) => {
      const numId = Number(key);
      if (!currentIds.has(key) && !Number.isNaN(numId) && numId > minId && numId < maxId) {
        msgCache.delete(key);
        deletedLogs.unshift(entry);
        if (deletedLogs.length > 40) deletedLogs.pop();
        toast('🔥 Deleted Msg Caught: ' + entry.text.slice(0, 36));

        const ghost = document.createElement('div');
        ghost.className = 'mental-deleted-ghost';
        ghost.dataset.mentalDeletedRestore = '1';
        ghost.innerHTML = '<span class="mental-deleted-tag">🔥 DELETED</span> <span style="color:#ffd6dc;font-size:12px"></span>';
        ghost.querySelector('span:last-child').textContent = entry.text + ' (' + entry.time + ')';
        container.appendChild(ghost);
      }
    });
  }
  setInterval(scanAndProtectMessages, 3800);

  // ===== UNICODE DRAGON / BOLD / GLITCH TEXT STYLER =====
  function toMathFont(str, upperStart, lowerStart, exceptions) {
    let out = '';
    for (let i = 0; i < str.length; i++) {
      const ch = str[i];
      const code = ch.charCodeAt(0);
      if (exceptions && exceptions[ch]) {
        out += exceptions[ch];
      } else if (code >= 65 && code <= 90) {
        out += String.fromCodePoint(upperStart + (code - 65));
      } else if (code >= 97 && code <= 122) {
        out += String.fromCodePoint(lowerStart + (code - 97));
      } else {
        out += ch;
      }
    }
    return out;
  }

  function convertFont(text, style) {
    if (!text) return '';
    if (style === 'dragon') {
      return toMathFont(text, 0x1D56C, 0x1D586, null);
    }
    if (style === 'bold') {
      return toMathFont(text, 0x1D400, 0x1D41A, null);
    }
    if (style === 'glitch') {
      const marks = ['\u0301', '\u0336', '\u0323', '\u0308'];
      let res = '';
      for (let i = 0; i < text.length; i++) {
        res += text[i] === ' ' ? ' ' : text[i] + marks[i % marks.length] + marks[(i + 1) % marks.length];
      }
      return res;
    }
    return text;
  }

  // ===== AUTO-TIMER / REPEAT SENDER =====
  let spamTimerId = 0;
  let spamRemaining = 0;

  // Sync saved hardware preferences into Kotlin bridge on boot
  function syncNativeBridge() {
    const b = window.MentalBridge;
    if (!b) return;
    try {
      if (b.setVolTriggerMode) b.setVolTriggerMode(cfg.volMode || 'OFF');
      if (cfg.audioRoute && cfg.audioRoute !== 'AUTO' && b.setAudioRoute) b.setAudioRoute(cfg.audioRoute);
      if (cfg.vcLock && b.setVcKeepAwake) b.setVcKeepAwake(true);
      if (cfg.screenSecure && b.setScreenPrivacy) b.setScreenPrivacy(true);
    } catch {}
  }
  setTimeout(syncNativeBridge, 800);

  function getOpenComposer() {
    return (
      document.querySelector('.input-message-input[contenteditable="true"]') ||
      document.querySelector('#editable-message-text[contenteditable="true"]') ||
      document.querySelector('.composer_rich_textarea[contenteditable="true"]')
    );
  }

  function getOpenChatTitle() {
    const el =
      document.querySelector('.top .peer-title') ||
      document.querySelector('.chat-info .peer-title') ||
      document.querySelector('.MiddleHeader .fullName') ||
      document.querySelector('.ChatInfo .fullName');
    const txt = el ? (el.textContent || '').trim() : '';
    return txt || 'Friend';
  }

  function isOpenChatPrivateDm() {
    const h = location.hash || '';
    if (/^#-\d+/.test(h)) return false;
    if (document.querySelector('.chat-info .chat-type-group, .MiddleHeader .group-status')) return false;
    const title = getOpenChatTitle();
    if (/^(Saved Messages|Telegram)$/i.test(title)) return false;
    return true;
  }

  function setComposerText(box, text) {
    box.focus();
    try {
      const sel = window.getSelection();
      const range = document.createRange();
      range.selectNodeContents(box);
      sel.removeAllRanges();
      sel.addRange(range);
      document.execCommand('insertText', false, text);
    } catch {
      box.textContent = text;
    }
    box.dispatchEvent(new Event('input', { bubbles: true }));
  }

  function sendTextInOpenChat(text) {
    const box = getOpenComposer();
    if (!box) return false;
    setComposerText(box, text);
    setTimeout(() => {
      const sendBtn =
        document.querySelector('.btn-send:not(.hide)') ||
        document.querySelector('button.send.main-button') ||
        document.querySelector('.Button.send');
      if (sendBtn) {
        sendBtn.click();
      } else {
        box.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
      }
    }, 160);
    return true;
  }

  // ===== FORMAT PLACEHOLDERS & SAFE HASH-LOCKED DELIVERY =====
  function fillTemplate(tpl, name) {
    const t = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    return String(tpl || '')
      .replace(/\{name\}/gi, name || 'Friend')
      .replace(/\{time\}/gi, t);
  }

  function deliverToChatHash(targetHash, text, onSent) {
    if (targetHash && location.hash !== targetHash) {
      location.hash = targetHash;
      setTimeout(() => {
        if (sendTextInOpenChat(text) && onSent) onSent();
      }, 750);
    } else {
      if (sendTextInOpenChat(text) && onSent) onSent();
    }
  }

  // ===== SCHEDULED DELAY MESSAGE QUEUE =====
  const scheduledQueue = [];
  setInterval(() => {
    if (!scheduledQueue.length) return;
    const now = Date.now();
    for (let i = scheduledQueue.length - 1; i >= 0; i--) {
      if (now >= scheduledQueue[i].deliverAt) {
        const job = scheduledQueue.splice(i, 1)[0];
        deliverToChatHash(job.targetHash, job.text, () => {
          toast('⏰ Scheduled Msg Sent -> ' + job.chatName);
        });
      }
    }
  }, 1000);

  // ===== MULTI-LINE SCRIPT DROPPER =====
  let scriptRunner = { active: false, timerId: 0, queue: [], targetHash: '' };
  function stopScriptDropper(silent) {
    if (scriptRunner.timerId) clearTimeout(scriptRunner.timerId);
    scriptRunner = { active: false, timerId: 0, queue: [], targetHash: '' };
    if (!silent) toast('⏹️ Script Dropper Stopped');
  }
  function stepScriptDropper(onUpdate) {
    if (!scriptRunner.active || !scriptRunner.queue.length) {
      stopScriptDropper(true);
      toast('✅ Script Drop Complete!');
      if (onUpdate) onUpdate();
      return;
    }
    const line = scriptRunner.queue.shift();
    deliverToChatHash(scriptRunner.targetHash, line, null);
    if (onUpdate) onUpdate();
    if (scriptRunner.queue.length > 0) {
      const waitMs = Math.max(1500, (Number(cfg.scriptDelaySec) || 3) * 1000);
      scriptRunner.timerId = window.setTimeout(() => stepScriptDropper(onUpdate), waitMs);
    } else {
      stopScriptDropper(true);
      toast('✅ Script Drop Complete!');
      if (onUpdate) onUpdate();
    }
  }

  // ===== SMART DELAY DM AUTO-REPLY + KEYWORD TRIGGER AUTO-REPLY =====
  let afkBusy = false;
  const seenKwMids = new Set();

  function parseKeywordRules() {
    return (cfg.kwRules || '')
      .split('\n')
      .map((line) => line.trim())
      .filter((line) => line.includes('='))
      .map((line) => {
        const idx = line.indexOf('=');
        return {
          key: line.slice(0, idx).trim().toLowerCase(),
          reply: line.slice(idx + 1).trim()
        };
      })
      .filter((r) => r.key.length > 0 && r.reply.length > 0);
  }

  function runKeywordTriggerScan() {
    if (!cfg.kwReplyEnabled) return;
    if (cfg.kwScope !== 'ALL' && !isOpenChatPrivateDm()) return;
    if (!getOpenComposer()) return;

    const rules = parseKeywordRules();
    if (!rules.length) return;

    const msgs = document.querySelectorAll('.bubble:not(.is-date), .Message');
    if (!msgs.length) return;
    const start = Math.max(0, msgs.length - 3);
    for (let i = start; i < msgs.length; i++) {
      const m = msgs[i];
      if (m.classList.contains('is-out') || m.classList.contains('own')) continue;
      const mid = m.getAttribute('data-mid') || m.getAttribute('data-message-id') || '';
      const textEl = m.querySelector('.message, .text-content, .translatable-message');
      const txt = textEl ? (textEl.textContent || '').trim() : '';
      if (!txt) continue;

      const sig = (location.hash || '') + '::' + (mid || txt.slice(0, 48));
      if (seenKwMids.has(sig)) continue;
      seenKwMids.add(sig);
      if (seenKwMids.size > 300) {
        const first = seenKwMids.values().next().value;
        seenKwMids.delete(first);
      }

      const lower = txt.toLowerCase();
      const matched = rules.find((r) => lower.includes(r.key));
      if (matched) {
        const targetHash = location.hash || '';
        const senderName = getOpenChatTitle();
        const replyText = fillTemplate(matched.reply, senderName);
        const delayMs = Math.max(0, Number(cfg.afkDelaySec) || 0) * 1000;
        if (delayMs > 0) {
          toast('⏳ Rule [' + matched.key + '] -> ' + (delayMs / 1000) + 's');
        }
        setTimeout(() => {
          deliverToChatHash(targetHash, replyText, () => {
            cfg.afkCount = (cfg.afkCount || 0) + 1;
            saveCfg();
            toast('🎯 Auto-Replied [' + matched.key + ']');
          });
        }, delayMs);
        break;
      }
    }
  }

  function scheduleAfkReply(senderName, targetHash) {
    const delaySec = Math.max(0, Number(cfg.afkDelaySec) || 0);
    const replyBody = fillTemplate(cfg.afkTemplate || 'Dear {name}, Thank you for msg me, my boss is busy now.', senderName);
    if (delaySec > 0) {
      toast('⏳ Delay Reply (' + delaySec + 's) -> ' + senderName);
    }
    setTimeout(() => {
      deliverToChatHash(targetHash, replyBody, () => {
        cfg.afkCount = (cfg.afkCount || 0) + 1;
        saveCfg();
        toast('🤖 Auto-Replied to ' + senderName);
      });
    }, delaySec * 1000);
  }

  function runAfkScan() {
    if (document.hidden || Date.now() < scrollPauseUntil) return;
    if (cfg.kwReplyEnabled) runKeywordTriggerScan();
    if (!cfg.afkEnabled || afkBusy) return;
    const cooldownMs = (cfg.afkCooldownMin || 15) * 60 * 1000;
    const now = Date.now();

    const listRoot = document.querySelector('.chatlist, .ChatList') || document;
    const rows = listRoot.querySelectorAll('.chatlist-chat, .ListItem.Chat');
    const maxScan = Math.min(rows.length, 24);
    for (let i = 0; i < maxScan; i++) {
      const row = rows[i];
      const badge = row.querySelector('.dialog-subtitle-badge.unread, .unread-count, .Badge.unread');
      if (!badge || !badge.textContent || !badge.textContent.trim()) continue;

      const pid = row.getAttribute('data-peer-id');
      const link = row.querySelector('a[href^="#"]');
      const hrefId = link ? (link.getAttribute('href') || '').replace('#', '') : '';
      const rawId = pid || hrefId;
      if (rawId && (rawId.startsWith('-') || rawId === '777000')) continue;
      if (row.querySelector('.tgico-group, .tgico-channel, .icon-group, .icon-channel')) continue;

      const titleEl = row.querySelector('.peer-title, .title h3, .user-title');
      const senderName = titleEl ? (titleEl.textContent || '').trim() : '';
      if (!senderName || /^(Saved Messages|Telegram)$/i.test(senderName)) continue;

      const key = rawId || senderName;
      if (repliedMap[key] && (now - repliedMap[key]) < cooldownMs) continue;

      afkBusy = true;
      repliedMap[key] = now;
      saveReplied();

      const clickTarget = row.querySelector('.ListItem-button') || row;
      clickTarget.click();

      setTimeout(() => {
        try {
          const msgs = document.querySelectorAll('.bubble:not(.is-date), .Message');
          const lastMsg = msgs.length ? msgs[msgs.length - 1] : null;
          const isOutgoing = lastMsg && (lastMsg.classList.contains('is-out') || lastMsg.classList.contains('own'));
          if (!isOutgoing) {
            scheduleAfkReply(senderName, location.hash || '');
          }
        } finally {
          afkBusy = false;
        }
      }, 650);
      return;
    }

    if (isOpenChatPrivateDm() && getOpenComposer()) {
      const msgs = document.querySelectorAll('.bubble:not(.is-date), .Message');
      const lastMsg = msgs.length ? msgs[msgs.length - 1] : null;
      if (lastMsg && !lastMsg.classList.contains('is-out') && !lastMsg.classList.contains('own')) {
        const senderName = getOpenChatTitle();
        const openKey = 'open_' + (location.hash || senderName);
        if (!repliedMap[openKey] || (now - repliedMap[openKey]) >= cooldownMs) {
          repliedMap[openKey] = now;
          saveReplied();
          scheduleAfkReply(senderName, location.hash || '');
        }
      }
    }
  }
  setInterval(runAfkScan, 4000);

  // ===== KEYWORD PING RADAR =====
  const seenRadar = new Set();
  function rememberSeen(sig) {
    if (seenRadar.has(sig)) return false;
    seenRadar.add(sig);
    if (seenRadar.size > 260) {
      const first = seenRadar.values().next().value;
      seenRadar.delete(first);
    }
    return true;
  }

  let radarBootstrapped = false;
  function runRadarScan() {
    if (!cfg.radarEnabled) { radarBootstrapped = false; return; }
    if (document.hidden || Date.now() < scrollPauseUntil) return;
    const words = (cfg.radarKeywords || '')
      .split(',')
      .map((s) => s.trim().toLowerCase())
      .filter((s) => s.length >= 2);
    if (!words.length) return;

    const listRoot = document.querySelector('.chatlist, .ChatList') || document;
    const rows = listRoot.querySelectorAll('.chatlist-chat, .ListItem.Chat');
    const maxScan = Math.min(rows.length, 24);
    for (let i = 0; i < maxScan; i++) {
      const row = rows[i];
      const titleEl = row.querySelector('.peer-title, .title h3, .user-title');
      const subEl = row.querySelector('.dialog-subtitle, .last-message');
      const title = titleEl ? (titleEl.textContent || '').trim() : 'Chat';
      const snippet = subEl ? (subEl.textContent || '').trim() : '';
      if (!snippet) continue;
      const sig = title + '::' + snippet.slice(0, 60);
      if (!rememberSeen(sig)) continue;
      if (!radarBootstrapped) continue;

      const lower = snippet.toLowerCase();
      const matched = words.find((w) => lower.includes(w));
      if (matched) {
        toast('📡 RADAR [' + matched + ']: ' + title);
        if (window.MentalBridge && window.MentalBridge.triggerRadarAlert) {
          window.MentalBridge.triggerRadarAlert(title, snippet.slice(0, 80));
        }
      }
    }
    radarBootstrapped = true;
  }
  setInterval(runRadarScan, 4500);

  // ===== POWER HUB SHADOW DOM DRAWER =====
  function mountPowerHub() {
    if (window.top !== window || document.getElementById('mentals-power-host')) return;

    const host = document.createElement('div');
    host.id = 'mentals-power-host';
    host.style.cssText = 'position:fixed;inset:0;z-index:2147483645;display:none;font-family:system-ui,-apple-system,sans-serif;';
    const shadow = host.attachShadow({ mode: 'open' });

    const activeSlot = window.MentalBridge && window.MentalBridge.getAccountSlot ? window.MentalBridge.getAccountSlot() : 1;

    shadow.innerHTML = `
      <style>
        .backdrop { position:fixed; inset:0; background:rgba(0,0,0,0.74); display:flex; align-items:flex-start; justify-content:center; padding:16px 10px; overflow-y:auto; }
        .card { width:100%; max-width:366px; background:#090305; border:1px solid #ef233c; box-shadow:0 0 28px rgba(239,35,60,0.45); color:#f4f4f5; padding:12px; }
        .top { display:flex; justify-content:space-between; align-items:center; padding-bottom:8px; margin-bottom:9px; border-bottom:1px solid rgba(239,35,60,0.4); }
        .top strong { font-size:13px; color:#ffb703; letter-spacing:0.08em; }
        .close { background:#1c070c; border:1px solid #ef233c; color:#fff; padding:4px 10px; font-size:10px; font-weight:800; cursor:pointer; }
        .tabs { display:grid; grid-template-columns:repeat(4,1fr); gap:4px; margin-bottom:10px; }
        .tab { background:#140609; border:1px solid #591420; color:#cbd5e1; padding:7px 2px; font-size:8.5px; font-weight:800; cursor:pointer; }
        .tab.active { background:#ef233c; border-color:#ffb703; color:#fff; }
        .pane { display:none; }
        .pane.active { display:block; }
        .box { background:#120508; border:1px solid #4a121c; padding:9px; margin-bottom:8px; }
        .lbl { font-size:10px; font-weight:800; color:#ffb703; letter-spacing:0.06em; margin-bottom:6px; display:flex; justify-content:space-between; align-items:center; }
        .row2 { display:grid; grid-template-columns:1fr 1fr; gap:6px; }
        .row3 { display:grid; grid-template-columns:repeat(3,1fr); gap:5px; }
        .row4 { display:grid; grid-template-columns:repeat(4,1fr); gap:4px; }
        .btn { background:#1b080d; border:1px solid #631826; color:#f4f4f5; padding:7px 5px; font-size:10px; font-weight:700; cursor:pointer; text-align:center; }
        .btn.on { background:rgba(239,35,60,0.34); border-color:#ffb703; color:#ffb703; }
        .btn.prime { background:linear-gradient(135deg,#ef233c,#9e001c); border-color:#ef233c; color:#fff; }
        textarea, input[type=text], select { width:100%; box-sizing:border-box; background:#060203; border:1px solid #631826; color:#fff; padding:7px; font-size:11px; font-family:inherit; margin-bottom:6px; }
        .hint { font-size:10px; color:#c9969e; line-height:1.35; }
        .del-log { max-height:95px; overflow-y:auto; font-size:10px; color:#ffd6dc; background:#060203; border:1px solid #4a121c; padding:6px; margin-top:6px; }
      </style>
      <div class="backdrop" id="bg">
        <div class="card">
          <div class="top">
            <strong>⚡ MENTALGRAM v3.3 POWER HUB</strong>
            <button class="close" id="closeHub">CLOSE</button>
          </div>
          <div class="tabs">
            <button class="tab active" data-t="vc">🎙️ VC/REC</button>
            <button class="tab" data-t="afk">🤖 AUTO BOT</button>
            <button class="tab" data-t="delay">⏱️ DELAY</button>
            <button class="tab" data-t="radar">🛡️ STEALTH</button>
          </div>

          <div class="pane active" id="pane-vc">
            <div class="box">
              <div class="lbl"><span>SCREEN + DUAL-VOICE RECORDER &amp; PiP</span></div>
              <div class="row2" style="margin-bottom:6px">
                <button class="btn prime" id="screenRecBtn">🎬 SCREEN REC</button>
                <button class="btn" id="recVcBtn">🔴 AUDIO ONLY</button>
              </div>
              <div class="row2">
                <button class="btn" id="vcLockBtn">VC LOCK</button>
                <button class="btn" id="pipBtn">📺 PiP BOX</button>
              </div>
              <div class="hint" style="margin-top:5px">🎬 SCREEN REC aapki Roar aawaj + saamne wale ki aawaj + screen video sab record karke Gallery/Movies me save karta hai.</div>
            </div>
            <div class="box">
              <div class="lbl"><span>VOLUME BUTTON TRIGGERS</span><span id="volTxt" style="color:#fff">OFF</span></div>
              <div class="row3">
                <button class="btn" data-vol="OFF">OFF</button>
                <button class="btn" data-vol="MUTE">VOL = MUTE</button>
                <button class="btn" data-vol="SFX">VOL = ROAR</button>
              </div>
            </div>
            <div class="box">
              <div class="lbl"><span>BLUETOOTH / SPEAKER / MIC ROUTE</span></div>
              <div class="row4">
                <button class="btn" data-rt="AUTO">AUTO</button>
                <button class="btn" data-rt="BLUETOOTH">BT</button>
                <button class="btn" data-rt="SPEAKER">SPK</button>
                <button class="btn" data-rt="EARPIECE">EAR</button>
              </div>
            </div>
            <div class="box">
              <div class="lbl"><span>500+ GC SPEED &amp; SLOW-NET BOOST</span></div>
              <div class="row2">
                <button class="btn" id="turboBtn">🚀 500+ GC: ON</button>
                <button class="btn prime" id="ramBtn">⚡ RAM BOOST</button>
              </div>
            </div>
          </div>

          <div class="pane" id="pane-afk">
            <div class="box">
              <div class="lbl"><span>HUMAN-DELAY DM AUTO-REPLY</span><span id="afkStat">0 SENT</span></div>
              <div class="row3" style="margin-bottom:6px">
                <button class="btn" id="afkToggleBtn">AFK: OFF</button>
                <button class="btn" id="afkDelayBtn">DELAY: 3s</button>
                <button class="btn" id="afkCooldownBtn">WAIT: 15m</button>
              </div>
              <textarea id="afkMsgInput" rows="2"></textarea>
              <div class="row2">
                <button class="btn prime" id="afkTestBtn">TEST IN OPEN DM</button>
                <button class="btn" id="afkResetBtn">RESET HISTORY</button>
              </div>
            </div>
            <div class="box">
              <div class="lbl"><span>KEYWORD TRIGGER AUTO-REPLY RULES</span></div>
              <div class="row2" style="margin-bottom:6px">
                <button class="btn" id="kwToggleBtn">RULES: OFF</button>
                <button class="btn" id="kwScopeBtn">DM ONLY</button>
              </div>
              <textarea id="kwRulesInput" rows="3" placeholder="keyword = reply (ek line me ek rule)"></textarea>
              <div class="hint">Format: <code style="color:#ffb703">vc = Aa rha hun {name}</code> · Aapki upar wali DELAY (0s-30s) setting follow hogi.</div>
            </div>
            <div class="box">
              <div class="lbl"><span>1-TAP QUICK DRAGON REPLIES</span></div>
              <div id="tplList" style="display:flex;flex-direction:column;gap:4px"></div>
            </div>
          </div>

          <div class="pane" id="pane-delay">
            <div class="box">
              <div class="lbl"><span>⏰ SCHEDULED DELAY MESSAGE</span><span id="schedStat">0 QUEUED</span></div>
              <input type="text" id="schedInput" placeholder="Baad me bhejne wala message likhein..." />
              <div class="row3" style="margin-bottom:6px">
                <select id="schedDelaySel" style="margin:0">
                  <option value="10">In 10s</option>
                  <option value="30">In 30s</option>
                  <option value="60">In 1 min</option>
                  <option value="300">In 5 min</option>
                  <option value="900">In 15 min</option>
                  <option value="1800">In 30 min</option>
                </select>
                <button class="btn prime" id="schedAddBtn">⏰ SCHEDULE</button>
                <button class="btn" id="schedClearBtn">CLEAR ALL</button>
              </div>
              <div class="del-log" id="schedListBox" style="max-height:64px">Koi scheduled message nahi hai...</div>
            </div>
            <div class="box">
              <div class="lbl"><span>📜 MULTI-LINE SCRIPT DROPPER</span></div>
              <textarea id="scriptInput" rows="3" placeholder="Har line ek ke baad ek delay se jayegi..."></textarea>
              <div class="row2">
                <button class="btn" id="scriptGapBtn">GAP: 3s</button>
                <button class="btn prime" id="scriptRunBtn">📜 DROP LINES</button>
              </div>
            </div>
            <div class="box">
              <div class="lbl"><span>𝕯 DRAGON FONT STYLER &amp; REPEAT TIMER</span></div>
              <input type="text" id="fontInput" placeholder="Yahan likhein (ya khali chhodkar open chat badlein)..." />
              <div class="row3" style="margin-bottom:6px">
                <button class="btn" data-fnt="dragon">𝕯𝖗𝖆𝖌𝖔𝖓</button>
                <button class="btn" data-fnt="bold">𝐁𝐎𝐋𝐃</button>
                <button class="btn" data-fnt="glitch">G̸l̸i̸t̸c̸h̸</button>
              </div>
              <div class="row3">
                <select id="spamSec" style="margin:0"><option value="5">5s</option><option value="15">15s</option><option value="30">30s</option></select>
                <select id="spamCnt" style="margin:0"><option value="3">3x</option><option value="5">5x</option><option value="10">10x</option></select>
                <button class="btn prime" id="spamBtn">⏱️ REPEAT</button>
              </div>
            </div>
          </div>

          <div class="pane" id="pane-radar">
            <div class="box">
              <div class="lbl"><span>STEALTH &amp; ANTI-DELETE</span></div>
              <div class="row3">
                <button class="btn" id="antiDelBtn">🔥 ANTI-DEL</button>
                <button class="btn" id="ghostBtn">👻 GHOST</button>
                <button class="btn" id="secBtn">🛡️ NO REC</button>
              </div>
              <div class="del-log" id="delLogBox">Deleted messages yahan capture honge...</div>
            </div>
            <div class="box">
              <div class="lbl"><span>MULTI-ACCOUNT (3 ISOLATED IDs)</span><span>ACTIVE: #` + activeSlot + `</span></div>
              <div class="row3">
                <button class="btn ${activeSlot === 1 ? 'on' : ''}" data-acc="1">ACC 1</button>
                <button class="btn ${activeSlot === 2 ? 'on' : ''}" data-acc="2">ACC 2</button>
                <button class="btn ${activeSlot === 3 ? 'on' : ''}" data-acc="3">ACC 3</button>
              </div>
            </div>
            <div class="box">
              <div class="lbl"><span>KEYWORD PING RADAR</span></div>
              <button class="btn" id="radarToggleBtn" style="width:100%;margin-bottom:6px">RADAR: OFF</button>
              <input type="text" id="radarKeysInput" placeholder="VC, join, @name" />
            </div>
          </div>
        </div>
      </div>
    `;

    const tabs = shadow.querySelectorAll('.tab');
    const panes = shadow.querySelectorAll('.pane');
    tabs.forEach((t) => t.addEventListener('click', () => {
      tabs.forEach((x) => x.classList.remove('active'));
      panes.forEach((x) => x.classList.remove('active'));
      t.classList.add('active');
      shadow.getElementById('pane-' + t.getAttribute('data-t')).classList.add('active');
    }));

    const vcLockBtn = shadow.getElementById('vcLockBtn');
    const screenRecBtn = shadow.getElementById('screenRecBtn');
    const recVcBtn = shadow.getElementById('recVcBtn');
    const turboBtn = shadow.getElementById('turboBtn');
    const afkToggleBtn = shadow.getElementById('afkToggleBtn');
    const afkDelayBtn = shadow.getElementById('afkDelayBtn');
    const afkCooldownBtn = shadow.getElementById('afkCooldownBtn');
    const afkStat = shadow.getElementById('afkStat');
    const afkMsgInput = shadow.getElementById('afkMsgInput');
    const kwToggleBtn = shadow.getElementById('kwToggleBtn');
    const kwScopeBtn = shadow.getElementById('kwScopeBtn');
    const kwRulesInput = shadow.getElementById('kwRulesInput');
    const schedInput = shadow.getElementById('schedInput');
    const schedDelaySel = shadow.getElementById('schedDelaySel');
    const schedStat = shadow.getElementById('schedStat');
    const schedListBox = shadow.getElementById('schedListBox');
    const scriptInput = shadow.getElementById('scriptInput');
    const scriptGapBtn = shadow.getElementById('scriptGapBtn');
    const scriptRunBtn = shadow.getElementById('scriptRunBtn');
    const radarToggleBtn = shadow.getElementById('radarToggleBtn');
    const radarKeysInput = shadow.getElementById('radarKeysInput');
    const antiDelBtn = shadow.getElementById('antiDelBtn');
    const ghostBtn = shadow.getElementById('ghostBtn');
    const secBtn = shadow.getElementById('secBtn');
    const delLogBox = shadow.getElementById('delLogBox');
    const fontInput = shadow.getElementById('fontInput');
    const spamBtn = shadow.getElementById('spamBtn');
    const tplList = shadow.getElementById('tplList');

    function syncUi() {
      vcLockBtn.textContent = cfg.vcLock ? '🔒 VC LOCK' : 'VC LOCK';
      vcLockBtn.classList.toggle('on', cfg.vcLock);

      screenRecBtn.textContent = screenRec.active ? '⏹️ STOP SCREEN REC' : '🎬 SCREEN REC';
      screenRecBtn.classList.toggle('on', screenRec.active);

      recVcBtn.textContent = recState.active ? '⏹️ STOP AUDIO' : '🔴 AUDIO ONLY';
      recVcBtn.classList.toggle('on', recState.active);

      shadow.getElementById('volTxt').textContent = cfg.volMode;
      shadow.querySelectorAll('[data-vol]').forEach((b) => {
        b.classList.toggle('on', b.getAttribute('data-vol') === cfg.volMode);
      });

      shadow.querySelectorAll('[data-rt]').forEach((b) => {
        b.classList.toggle('on', b.getAttribute('data-rt') === cfg.audioRoute);
      });

      turboBtn.textContent = cfg.turboLite ? '🚀 500+ GC: ON' : '🚀 500+ GC: OFF';
      turboBtn.classList.toggle('on', cfg.turboLite);

      afkToggleBtn.textContent = cfg.afkEnabled ? '🤖 AFK: ON' : 'AFK: OFF';
      afkToggleBtn.classList.toggle('on', cfg.afkEnabled);
      afkDelayBtn.textContent = 'DELAY: ' + (cfg.afkDelaySec || 0) + 's';
      afkDelayBtn.classList.toggle('on', (cfg.afkDelaySec || 0) > 0);
      afkCooldownBtn.textContent = 'WAIT: ' + cfg.afkCooldownMin + 'm';
      afkStat.textContent = (cfg.afkCount || 0) + ' SENT';
      if (document.activeElement !== afkMsgInput) afkMsgInput.value = cfg.afkTemplate;

      kwToggleBtn.textContent = cfg.kwReplyEnabled ? '🎯 RULES: ON' : 'RULES: OFF';
      kwToggleBtn.classList.toggle('on', cfg.kwReplyEnabled);
      kwScopeBtn.textContent = cfg.kwScope === 'ALL' ? 'DM + OPEN GC' : 'DM ONLY';
      kwScopeBtn.classList.toggle('on', cfg.kwScope === 'ALL');
      if (document.activeElement !== kwRulesInput) kwRulesInput.value = cfg.kwRules || '';

      schedStat.textContent = scheduledQueue.length + ' QUEUED';
      schedListBox.innerHTML = scheduledQueue.length
        ? scheduledQueue.map((j) => {
            const left = Math.max(0, Math.ceil((j.deliverAt - Date.now()) / 1000));
            return '<div><strong style="color:#ffb703">[' + left + 's -> ' + j.chatName.replace(/</g, '&lt;') + ']</strong> ' + j.text.slice(0, 34).replace(/</g, '&lt;') + '</div>';
          }).join('')
        : 'Koi scheduled message nahi hai...';

      if (document.activeElement !== scriptInput) scriptInput.value = cfg.scriptLines || '';
      scriptGapBtn.textContent = 'GAP: ' + (cfg.scriptDelaySec || 3) + 's';
      scriptRunBtn.textContent = scriptRunner.active ? '⏹️ STOP (' + scriptRunner.queue.length + ')' : '📜 DROP LINES';
      scriptRunBtn.classList.toggle('on', scriptRunner.active);

      antiDelBtn.textContent = cfg.antiDelete ? '🔥 ANTI-DEL: ON' : 'ANTI-DEL: OFF';
      antiDelBtn.classList.toggle('on', cfg.antiDelete);
      ghostBtn.textContent = cfg.ghostMode ? '👻 GHOST: ON' : 'GHOST: OFF';
      ghostBtn.classList.toggle('on', cfg.ghostMode);
      secBtn.textContent = cfg.screenSecure ? '🛡️ NO REC: ON' : 'NO REC: OFF';
      secBtn.classList.toggle('on', cfg.screenSecure);

      delLogBox.innerHTML = deletedLogs.length
        ? deletedLogs.map((d) => '<div><strong style="color:#ff4d6d">[' + d.time + ']</strong> ' + d.text.replace(/</g, '&lt;') + '</div>').join('')
        : 'Deleted messages yahan capture honge...';

      spamBtn.textContent = spamTimerId ? '⏹️ STOP (' + spamRemaining + ')' : '⏱️ REPEAT';

      radarToggleBtn.textContent = cfg.radarEnabled ? '📡 RADAR: ARMED' : 'RADAR: OFF';
      radarToggleBtn.classList.toggle('on', cfg.radarEnabled);
      if (document.activeElement !== radarKeysInput) radarKeysInput.value = cfg.radarKeywords;

      tplList.innerHTML = '';
      (cfg.templates || []).forEach((txt, idx) => {
        const b = document.createElement('button');
        b.className = 'btn';
        b.textContent = (idx + 1) + '. ' + txt;
        b.addEventListener('click', () => {
          host.style.display = 'none';
          if (sendTextInOpenChat(txt)) toast('⚡ Sent Template #' + (idx + 1));
          else toast('⚠️ Pehle koi chat open karein');
        });
        tplList.appendChild(b);
      });
    }

    vcLockBtn.addEventListener('click', () => {
      cfg.vcLock = !cfg.vcLock;
      saveCfg();
      if (window.MentalBridge && window.MentalBridge.setVcKeepAwake) window.MentalBridge.setVcKeepAwake(cfg.vcLock);
      syncUi();
      toast(cfg.vcLock ? '🔒 Screen-Off VC Lock ON' : 'VC Lock OFF');
    });

    screenRec.onUi = syncUi;
    screenRecBtn.addEventListener('click', () => {
      if (screenRec.active) {
        window.__mentalsStopScreenRec();
      } else {
        host.style.display = 'none';
        if (window.MentalBridge && window.MentalBridge.requestScreenRec) {
          window.MentalBridge.requestScreenRec();
        } else {
          toast('⚠️ Screen Recorder APK ke andar chalega');
        }
      }
    });

    recVcBtn.addEventListener('click', () => {
      toggleVcRecording(syncUi);
    });

    shadow.getElementById('pipBtn').addEventListener('click', () => {
      host.style.display = 'none';
      if (window.MentalBridge && window.MentalBridge.enterPipMode) window.MentalBridge.enterPipMode();
    });

    shadow.querySelectorAll('[data-vol]').forEach((b) => b.addEventListener('click', () => {
      cfg.volMode = b.getAttribute('data-vol');
      saveCfg();
      if (window.MentalBridge && window.MentalBridge.setVolTriggerMode) window.MentalBridge.setVolTriggerMode(cfg.volMode);
      syncUi();
      toast('🎛️ Volume Keys: ' + cfg.volMode);
    }));

    shadow.querySelectorAll('[data-rt]').forEach((b) => b.addEventListener('click', () => {
      cfg.audioRoute = b.getAttribute('data-rt');
      saveCfg();
      if (window.MentalBridge && window.MentalBridge.setAudioRoute) window.MentalBridge.setAudioRoute(cfg.audioRoute);
      syncUi();
      toast('🎧 Audio Route: ' + cfg.audioRoute);
    }));

    turboBtn.addEventListener('click', () => {
      cfg.turboLite = !cfg.turboLite;
      saveCfg();
      applyTurboClass();
      syncUi();
      toast(cfg.turboLite ? '🚀 Turbo Slow-Net Mode ON' : 'Turbo Mode OFF');
    });

    shadow.getElementById('ramBtn').addEventListener('click', () => {
      host.style.display = 'none';
      if (window.MentalBridge && window.MentalBridge.boostRam) window.MentalBridge.boostRam();
      else location.reload();
    });

    afkToggleBtn.addEventListener('click', () => {
      cfg.afkEnabled = !cfg.afkEnabled;
      saveCfg();
      syncUi();
      toast(cfg.afkEnabled ? '🤖 DM Auto-Reply ACTIVE' : 'Auto-Reply Paused');
    });

    afkDelayBtn.addEventListener('click', () => {
      const delays = [0, 3, 8, 15, 30];
      const cur = delays.indexOf(Number(cfg.afkDelaySec));
      cfg.afkDelaySec = delays[(cur + 1) % delays.length];
      saveCfg();
      syncUi();
      toast('⏳ Auto-Reply Delay: ' + cfg.afkDelaySec + 's');
    });

    afkCooldownBtn.addEventListener('click', () => {
      const steps = [5, 15, 60];
      cfg.afkCooldownMin = steps[(steps.indexOf(cfg.afkCooldownMin) + 1) % steps.length];
      saveCfg();
      syncUi();
    });

    afkMsgInput.addEventListener('input', () => {
      cfg.afkTemplate = afkMsgInput.value;
      saveCfg();
    });

    shadow.getElementById('afkTestBtn').addEventListener('click', () => {
      const name = getOpenChatTitle();
      const body = fillTemplate(cfg.afkTemplate || 'Dear {name}, Thank you for msg me, my boss is busy now.', name);
      host.style.display = 'none';
      if (sendTextInOpenChat(body)) toast('🤖 Sent Test Reply to ' + name);
      else toast('⚠️ Pehle koi DM chat open karein');
    });

    shadow.getElementById('afkResetBtn').addEventListener('click', () => {
      repliedMap = {};
      seenKwMids.clear();
      saveReplied();
      toast('🔄 Auto-Reply & Rule History Cleared');
    });

    kwToggleBtn.addEventListener('click', () => {
      cfg.kwReplyEnabled = !cfg.kwReplyEnabled;
      saveCfg();
      syncUi();
      toast(cfg.kwReplyEnabled ? '🎯 Keyword Auto-Reply ON' : 'Keyword Rules OFF');
    });

    kwScopeBtn.addEventListener('click', () => {
      cfg.kwScope = cfg.kwScope === 'ALL' ? 'DM' : 'ALL';
      saveCfg();
      syncUi();
      toast(cfg.kwScope === 'ALL' ? '🌐 Scope: DM + Open GC' : '🔒 Scope: DMs Only');
    });

    kwRulesInput.addEventListener('input', () => {
      cfg.kwRules = kwRulesInput.value;
      saveCfg();
    });

    shadow.getElementById('schedAddBtn').addEventListener('click', () => {
      const text = schedInput.value.trim();
      if (!text) {
        toast('⚠️ Pehle schedule message likhein');
        return;
      }
      if (!getOpenComposer()) {
        toast('⚠️ Pehle koi chat open karein');
        return;
      }
      const sec = Number(schedDelaySel.value) || 60;
      scheduledQueue.push({
        text,
        targetHash: location.hash || '',
        chatName: getOpenChatTitle(),
        deliverAt: Date.now() + sec * 1000
      });
      schedInput.value = '';
      syncUi();
      toast('⏰ Scheduled in ' + sec + 's -> ' + getOpenChatTitle());
    });

    shadow.getElementById('schedClearBtn').addEventListener('click', () => {
      scheduledQueue.length = 0;
      syncUi();
      toast('🗑️ Scheduled Queue Cleared');
    });

    scriptInput.addEventListener('input', () => {
      cfg.scriptLines = scriptInput.value;
      saveCfg();
    });

    scriptGapBtn.addEventListener('click', () => {
      const gaps = [2, 3, 5, 8, 12];
      const cur = gaps.indexOf(Number(cfg.scriptDelaySec));
      cfg.scriptDelaySec = gaps[(cur + 1) % gaps.length];
      saveCfg();
      syncUi();
    });

    scriptRunBtn.addEventListener('click', () => {
      if (scriptRunner.active) {
        stopScriptDropper(false);
        syncUi();
        return;
      }
      const lines = (scriptInput.value || '').split('\n').map((s) => s.trim()).filter(Boolean);
      if (!lines.length) {
        toast('⚠️ Script lines likhein');
        return;
      }
      if (!getOpenComposer()) {
        toast('⚠️ Pehle koi chat open karein');
        return;
      }
      scriptRunner = { active: true, timerId: 0, queue: lines, targetHash: location.hash || '' };
      host.style.display = 'none';
      stepScriptDropper(syncUi);
    });

    shadow.querySelectorAll('[data-fnt]').forEach((b) => b.addEventListener('click', () => {
      const style = b.getAttribute('data-fnt');
      const box = getOpenComposer();
      const raw = fontInput.value.trim() || (box ? (box.textContent || '').trim() : '');
      if (!raw) {
        toast('⚠️ Pehle text likhein');
        return;
      }
      const styled = convertFont(raw, style);
      if (fontInput.value.trim()) {
        host.style.display = 'none';
        sendTextInOpenChat(styled);
        fontInput.value = '';
      } else if (box) {
        host.style.display = 'none';
        setComposerText(box, styled);
      }
      toast('𝕯 Stylish Font Applied!');
    }));

    spamBtn.addEventListener('click', () => {
      if (spamTimerId) {
        clearInterval(spamTimerId);
        spamTimerId = 0;
        spamRemaining = 0;
        syncUi();
        toast('⏹️ Timer Sender Stopped');
        return;
      }
      const msg = fontInput.value.trim();
      if (!msg) {
        toast('⚠️ Upar box me message likhein');
        return;
      }
      const sec = Number(shadow.getElementById('spamSec').value) || 5;
      spamRemaining = Number(shadow.getElementById('spamCnt').value) || 3;
      host.style.display = 'none';
      sendTextInOpenChat(msg);
      spamRemaining--;
      if (spamRemaining > 0) {
        spamTimerId = window.setInterval(() => {
          if (spamRemaining <= 0) {
            clearInterval(spamTimerId);
            spamTimerId = 0;
            return;
          }
          sendTextInOpenChat(msg);
          spamRemaining--;
          if (spamRemaining <= 0) {
            clearInterval(spamTimerId);
            spamTimerId = 0;
          }
        }, sec * 1000);
      }
      syncUi();
    });

    antiDelBtn.addEventListener('click', () => {
      cfg.antiDelete = !cfg.antiDelete;
      saveCfg();
      syncUi();
      toast(cfg.antiDelete ? '🔥 Anti-Delete Catcher ON' : 'Anti-Delete OFF');
    });

    ghostBtn.addEventListener('click', () => {
      cfg.ghostMode = !cfg.ghostMode;
      saveCfg();
      syncUi();
      toast(cfg.ghostMode ? '👻 Ghost Mode: Typing Hidden' : 'Ghost Mode OFF');
    });

    secBtn.addEventListener('click', () => {
      cfg.screenSecure = !cfg.screenSecure;
      saveCfg();
      if (window.MentalBridge && window.MentalBridge.setScreenPrivacy) window.MentalBridge.setScreenPrivacy(cfg.screenSecure);
      syncUi();
      toast(cfg.screenSecure ? '🛡️ Screen Recording Blocked!' : 'Screen Privacy OFF');
    });

    shadow.querySelectorAll('[data-acc]').forEach((b) => b.addEventListener('click', () => {
      const slot = Number(b.getAttribute('data-acc'));
      host.style.display = 'none';
      if (window.MentalBridge && window.MentalBridge.switchAccount) window.MentalBridge.switchAccount(slot);
    }));

    radarToggleBtn.addEventListener('click', () => {
      cfg.radarEnabled = !cfg.radarEnabled;
      saveCfg();
      syncUi();
      toast(cfg.radarEnabled ? '📡 Keyword Ping Radar ARMED' : 'Radar OFF');
    });

    radarKeysInput.addEventListener('input', () => {
      cfg.radarKeywords = radarKeysInput.value;
      saveCfg();
    });

    shadow.getElementById('closeHub').addEventListener('click', () => { host.style.display = 'none'; });
    shadow.getElementById('bg').addEventListener('click', (e) => {
      if (e.target.id === 'bg') host.style.display = 'none';
    });

    window.__mentalsOpenPowerHub = () => {
      syncUi();
      host.style.display = 'block';
    };

    document.documentElement.appendChild(host);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', mountPowerHub);
  } else {
    mountPowerHub();
  }
})();
