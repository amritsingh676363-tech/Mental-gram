package com.mentals.telegram.dragon

class Slot3Activity : MainActivity() {
    override fun getAccountSlot(): Int = 3
}
