package com.mentals.telegram.dragon

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaRecorder
import android.media.MediaScannerConnection
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.util.Base64
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer

class DragonScreenRecService : Service() {

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var mediaRecorder: MediaRecorder? = null
    private var videoFile: File? = null
    private var pcmFile: File? = null
    private var pcmOut: BufferedOutputStream? = null
    private val pcmLock = Any()
    private val mainHandler = Handler(Looper.getMainLooper())

    companion object {
        const val ACTION_START = "com.mentals.telegram.dragon.SCREEN_REC_START"
        const val ACTION_APPEND_PCM = "com.mentals.telegram.dragon.SCREEN_REC_PCM"
        const val ACTION_STOP = "com.mentals.telegram.dragon.SCREEN_REC_STOP"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA_INTENT = "data_intent"
        const val EXTRA_PCM_B64 = "pcm_b64"
        const val EXTRA_SAMPLE_RATE = "sample_rate"
        private const val CHANNEL_ID = "mentalgram_screen_rec"
        private const val NOTIF_ID = 4043
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                ensureChannel()
                try {
                    val fgsType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                    } else {
                        0
                    }
                    ServiceCompat.startForeground(this, NOTIF_ID, buildNotification(), fgsType)
                } catch (_: Exception) {
                    stopSelf()
                    return START_NOT_STICKY
                }

                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                @Suppress("DEPRECATION")
                val dataIntent = intent.getParcelableExtra<Intent>(EXTRA_DATA_INTENT)
                if (resultCode != Activity.RESULT_OK || dataIntent == null) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                startProjectionRecording(resultCode, dataIntent)
            }
            ACTION_APPEND_PCM -> {
                val b64 = intent.getStringExtra(EXTRA_PCM_B64)
                if (!b64.isNullOrEmpty()) {
                    try {
                        val bytes = Base64.decode(b64, Base64.DEFAULT)
                        synchronized(pcmLock) {
                            pcmOut?.write(bytes)
                        }
                    } catch (_: Exception) {
                    }
                }
            }
            ACTION_STOP -> {
                val sampleRate = intent.getIntExtra(EXTRA_SAMPLE_RATE, 48000)
                finishAndMux(sampleRate)
            }
        }
        return START_NOT_STICKY
    }

    private fun startProjectionRecording(resultCode: Int, dataIntent: Intent) {
        try {
            val dm = resources.displayMetrics
            val rawW = dm.widthPixels.coerceAtLeast(360)
            val rawH = dm.heightPixels.coerceAtLeast(640)
            val scale = if (rawW > 720) 720f / rawW else 1f
            val width = ((rawW * scale).toInt() / 16) * 16
            val height = ((rawH * scale).toInt() / 16) * 16
            val density = dm.densityDpi

            val workDir = File(cacheDir, "srec").apply { mkdirs() }
            videoFile = File(workDir, "tmp_video.mp4").apply { if (exists()) delete() }
            pcmFile = File(workDir, "tmp_audio.pcm").apply { if (exists()) delete() }
            synchronized(pcmLock) {
                pcmOut?.close()
                pcmOut = BufferedOutputStream(FileOutputStream(pcmFile!!))
            }

            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val proj = mpm.getMediaProjection(resultCode, dataIntent)
            mediaProjection = proj

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                proj.registerCallback(object : MediaProjection.Callback() {
                    override fun onStop() {
                        mainHandler.post { cleanupProjectionOnly() }
                    }
                }, mainHandler)
            }

            @Suppress("DEPRECATION")
            val rec = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(this)
            } else {
                MediaRecorder()
            }
            rec.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            rec.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            rec.setVideoSize(width, height)
            rec.setVideoFrameRate(30)
            rec.setVideoEncodingBitRate(3_000_000)
            rec.setOutputFile(videoFile!!.absolutePath)
            rec.prepare()

            virtualDisplay = proj.createVirtualDisplay(
                "MentalgramScreenRec",
                width,
                height,
                density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                rec.surface,
                null,
                null
            )
            rec.start()
            mediaRecorder = rec
        } catch (_: Exception) {
            cleanupProjectionOnly()
            stopSelf()
        }
    }

    private fun finishAndMux(sampleRate: Int) {
        val vFile = videoFile
        val pFile = pcmFile
        synchronized(pcmLock) {
            try {
                pcmOut?.flush()
                pcmOut?.close()
            } catch (_: Exception) {
            }
            pcmOut = null
        }
        cleanupProjectionOnly()

        Thread {
            var savedName: String? = null
            val workDir = File(cacheDir, "srec").apply { mkdirs() }
            val outMp4 = File(workDir, "Mentalgram_ScreenRec_${System.currentTimeMillis()}.mp4")
            try {
                if (vFile != null && vFile.exists() && vFile.length() > 1024) {
                    val hasPcm = pFile != null && pFile.exists() && pFile.length() > 2048
                    val muxedOk = if (hasPcm) {
                        muxVideoAndPcmToMp4(vFile, pFile!!, sampleRate, outMp4)
                    } else {
                        false
                    }
                    val sourceToExport = if (muxedOk && outMp4.exists() && outMp4.length() > 1024) outMp4 else vFile
                    savedName = exportMp4ToPublic(sourceToExport)
                }
            } catch (_: Exception) {
            } finally {
                try { vFile?.delete() } catch (_: Exception) {}
                try { pFile?.delete() } catch (_: Exception) {}
                try { outMp4.delete() } catch (_: Exception) {}
            }

            mainHandler.post {
                val msg = if (savedName != null) {
                    "🎬 Screen Rec Saved (Roar + Call): $savedName"
                } else {
                    "⚠️ Screen recording save nahi ho payi"
                }
                Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show()
                stopSelf()
            }
        }.start()
    }

    private fun muxVideoAndPcmToMp4(vFile: File, pFile: File, sampleRate: Int, outMp4: File): Boolean {
        val aacRawFile = File(outMp4.parentFile, "tmp_aac.raw")
        val aacIdxFile = File(outMp4.parentFile, "tmp_aac.idx")
        var aacFormat: MediaFormat? = null

        var encoder: MediaCodec? = null
        try {
            val reqFormat = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sampleRate, 1).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, 128_000)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
            }
            encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            encoder.configure(reqFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            encoder.start()

            BufferedInputStream(FileInputStream(pFile)).use { pcmIn ->
                BufferedOutputStream(FileOutputStream(aacRawFile)).use { rawOut ->
                    DataOutputStream(BufferedOutputStream(FileOutputStream(aacIdxFile))).use { idxOut ->
                        val readBuf = ByteArray(4096)
                        val info = MediaCodec.BufferInfo()
                        var totalSamples = 0L
                        var sawInputEos = false
                        var sawOutputEos = false

                        while (!sawOutputEos) {
                            if (!sawInputEos) {
                                val inIdx = encoder.dequeueInputBuffer(10_000)
                                if (inIdx >= 0) {
                                    val inBuf = encoder.getInputBuffer(inIdx)!!
                                    inBuf.clear()
                                    val maxRead = minOf(readBuf.size, inBuf.remaining())
                                    val n = pcmIn.read(readBuf, 0, maxRead)
                                    val ptsUs = (totalSamples * 1_000_000L) / sampleRate
                                    if (n < 0) {
                                        encoder.queueInputBuffer(inIdx, 0, 0, ptsUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                        sawInputEos = true
                                    } else {
                                        inBuf.put(readBuf, 0, n)
                                        totalSamples += (n / 2)
                                        encoder.queueInputBuffer(inIdx, 0, n, ptsUs, 0)
                                    }
                                }
                            }

                            var outIdx = encoder.dequeueOutputBuffer(info, 10_000)
                            while (outIdx >= 0 || outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                                if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                                    aacFormat = encoder.outputFormat
                                } else if (outIdx >= 0) {
                                    val outBuf = encoder.getOutputBuffer(outIdx)!!
                                    if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0 && info.size > 0) {
                                        outBuf.position(info.offset)
                                        outBuf.limit(info.offset + info.size)
                                        val frame = ByteArray(info.size)
                                        outBuf.get(frame)
                                        rawOut.write(frame)
                                        idxOut.writeInt(info.size)
                                        idxOut.writeLong(info.presentationTimeUs)
                                        idxOut.writeInt(info.flags)
                                    }
                                    encoder.releaseOutputBuffer(outIdx, false)
                                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                                        sawOutputEos = true
                                        break
                                    }
                                }
                                outIdx = encoder.dequeueOutputBuffer(info, 0)
                            }
                        }
                    }
                }
            }
        } catch (_: Exception) {
            return false
        } finally {
            try { encoder?.stop() } catch (_: Exception) {}
            try { encoder?.release() } catch (_: Exception) {}
        }

        if (aacFormat == null || !aacRawFile.exists() || !aacIdxFile.exists()) {
            aacRawFile.delete()
            aacIdxFile.delete()
            return false
        }

        val extractor = MediaExtractor()
        var muxer: MediaMuxer? = null
        return try {
            extractor.setDataSource(vFile.absolutePath)
            var srcVideoTrack = -1
            var videoFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val fmt = extractor.getTrackFormat(i)
                val mime = fmt.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("video/")) {
                    srcVideoTrack = i
                    videoFormat = fmt
                    break
                }
            }
            if (srcVideoTrack < 0 || videoFormat == null) return false

            muxer = MediaMuxer(outMp4.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val dstVideoTrack = muxer.addTrack(videoFormat)
            val dstAudioTrack = muxer.addTrack(aacFormat!!)
            muxer.start()

            extractor.selectTrack(srcVideoTrack)
            val vBuf = ByteBuffer.allocate(512 * 1024)
            val vInfo = MediaCodec.BufferInfo()
            while (true) {
                val size = extractor.readSampleData(vBuf, 0)
                if (size < 0) break
                vInfo.offset = 0
                vInfo.size = size
                vInfo.presentationTimeUs = extractor.sampleTime
                @Suppress("DEPRECATION")
                vInfo.flags = extractor.sampleFlags
                muxer.writeSampleData(dstVideoTrack, vBuf, vInfo)
                extractor.advance()
            }

            DataInputStream(BufferedInputStream(FileInputStream(aacRawFile))).use { rawIn ->
                DataInputStream(BufferedInputStream(FileInputStream(aacIdxFile))).use { idxIn ->
                    val aInfo = MediaCodec.BufferInfo()
                    while (idxIn.available() > 0) {
                        val size = idxIn.readInt()
                        val pts = idxIn.readLong()
                        val aFlags = idxIn.readInt()
                        val frame = ByteArray(size)
                        rawIn.readFully(frame)
                        aInfo.set(0, size, pts, aFlags)
                        muxer.writeSampleData(dstAudioTrack, ByteBuffer.wrap(frame), aInfo)
                    }
                }
            }
            muxer.stop()
            true
        } catch (_: Exception) {
            false
        } finally {
            try { extractor.release() } catch (_: Exception) {}
            try { muxer?.release() } catch (_: Exception) {}
            aacRawFile.delete()
            aacIdxFile.delete()
        }
    }

    private fun exportMp4ToPublic(src: File): String? {
        val fileName = "Mentalgram_ScreenRec_${System.currentTimeMillis()}.mp4"
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Mentalgram")
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return null
            contentResolver.openOutputStream(uri)?.use { out ->
                FileInputStream(src).use { it.copyTo(out) }
            }
            fileName
        } else {
            @Suppress("DEPRECATION")
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "Mentalgram")
            if (!dir.exists()) dir.mkdirs()
            val dst = File(dir, fileName)
            FileInputStream(src).use { inp ->
                FileOutputStream(dst).use { out -> inp.copyTo(out) }
            }
            MediaScannerConnection.scanFile(applicationContext, arrayOf(dst.absolutePath), arrayOf("video/mp4"), null)
            fileName
        }
    }

    private fun cleanupProjectionOnly() {
        try { mediaRecorder?.stop() } catch (_: Exception) {}
        try { mediaRecorder?.reset() } catch (_: Exception) {}
        try { mediaRecorder?.release() } catch (_: Exception) {}
        mediaRecorder = null
        try { virtualDisplay?.release() } catch (_: Exception) {}
        virtualDisplay = null
        try { mediaProjection?.stop() } catch (_: Exception) {}
        mediaProjection = null
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val ch = NotificationChannel(CHANNEL_ID, "Mentalgram Screen Recorder", NotificationManager.IMPORTANCE_LOW)
            nm.createNotificationChannel(ch)
        }
    }

    private fun buildNotification(): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pi = PendingIntent.getActivity(this, 1, openIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("🎬 MENTALSGRAM SCREEN REC ACTIVE")
            .setContentText("Recording Screen + Roar & Call Voice")
            .setSmallIcon(android.R.drawable.presence_video_online)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        cleanupProjectionOnly()
        super.onDestroy()
    }
}
