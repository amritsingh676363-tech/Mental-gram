package com.mentals.telegram.dragon

import android.Manifest
import android.annotation.SuppressLint
import android.app.Dialog
import android.app.PictureInPictureParams
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.MediaStore
import android.util.Base64
import android.util.Rational
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileOutputStream

open class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var splashOverlay: LinearLayout
    private var pendingWebPermission: PermissionRequest? = null
    private var fileUploadCallback: ValueCallback<Array<Uri>>? = null
    private lateinit var dspPayload: String
    private lateinit var voiceChangerPayload: String
    private lateinit var themePayload: String
    private lateinit var powersPayload: String
    private var volTriggerMode: String = "OFF"
    private var lastInjectedBaseUrl: String = ""

    open fun getAccountSlot(): Int = 1

    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val cb = fileUploadCallback
        fileUploadCallback = null
        if (cb != null) {
            val parsed = WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
            cb.onReceiveValue(parsed)
        }
    }

    private val screenRecLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            val svcIntent = Intent(this, DragonScreenRecService::class.java).apply {
                action = DragonScreenRecService.ACTION_START
                putExtra(DragonScreenRecService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(DragonScreenRecService.EXTRA_DATA_INTENT, result.data)
            }
            try {
                ContextCompat.startForegroundService(this, svcIntent)
                webView.evaluateJavascript("window.__mentalsOnScreenRecStarted && window.__mentalsOnScreenRecStarted()", null)
            } catch (_: Exception) {
                Toast.makeText(this, "⚠️ Screen recorder start failed", Toast.LENGTH_SHORT).show()
            }
        }
    }

    companion object {
        private const val REQ_AUDIO_CODE = 9001
        private const val TELEGRAM_URL = "https://web.telegram.org/k/"
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        val slot = getAccountSlot()
        if (slot > 1 && Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try {
                WebView.setDataDirectorySuffix("mentals_slot_$slot")
            } catch (_: Throwable) {
            }
        }

        super.onCreate(savedInstanceState)

        window.statusBarColor = Color.parseColor("#060304")
        window.navigationBarColor = Color.parseColor("#060304")
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        dspPayload = assets.open("mentals_dsp.js").bufferedReader().use { it.readText() }
        voiceChangerPayload = assets.open("mentals_voice_changer.js").bufferedReader().use { it.readText() }
        themePayload = assets.open("mentals_theme.js").bufferedReader().use { it.readText() }
        powersPayload = assets.open("mentals_powers.js").bufferedReader().use { it.readText() }

        val rootContainer = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#060304"))
        }

        webView = WebView(this).apply {
            setBackgroundColor(Color.parseColor("#060304"))
            setLayerType(View.LAYER_TYPE_HARDWARE, null)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            settings.userAgentString =
                "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"
            addJavascriptInterface(MentalJsBridge(), "MentalBridge")
        }

        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(webView, true)
        }

        splashOverlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#060304"))

            val iconView = ImageView(this@MainActivity).apply {
                setImageResource(R.drawable.ic_launcher_fg)
                val sizePx = TypedValue.applyDimension(
                    TypedValue.COMPLEX_UNIT_DIP, 128f, resources.displayMetrics
                ).toInt()
                layoutParams = LinearLayout.LayoutParams(sizePx, sizePx)
            }

            val titleView = TextView(this@MainActivity).apply {
                text = if (slot > 1) "MENTALSGRAM #$slot" else "MENTALSGRAM"
                setTextColor(Color.parseColor("#EF233C"))
                textSize = 24f
                setTypeface(Typeface.SERIF, Typeface.BOLD_ITALIC)
                letterSpacing = 0.16f
                gravity = Gravity.CENTER
            }

            val subView = TextView(this@MainActivity).apply {
                text = "DRAGON ROAR DSP v3.2  •  GOD MODE"
                setTextColor(Color.parseColor("#FFB703"))
                textSize = 11f
                typeface = Typeface.MONOSPACE
                letterSpacing = 0.12f
                gravity = Gravity.CENTER
                setPadding(0, 14, 0, 0)
            }

            addView(iconView)
            addView(titleView)
            addView(subView)
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                if (url.startsWith("https://web.telegram.org") || url.startsWith("https://oauth.telegram.org")) {
                    return false
                }
                if (url.startsWith("http://") || url.startsWith("https://") || url.startsWith("tg://")) {
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                    } catch (_: Exception) {
                    }
                    return true
                }
                return false
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                lastInjectedBaseUrl = url?.substringBefore("#") ?: ""
                injectMentalgram(view)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                lastInjectedBaseUrl = url?.substringBefore("#") ?: ""
                injectMentalgram(view)
                CookieManager.getInstance().flush()
                if (splashOverlay.visibility == View.VISIBLE) {
                    splashOverlay.animate()
                        .alpha(0f)
                        .setDuration(240)
                        .withEndAction { splashOverlay.visibility = View.GONE }
                        .start()
                }
            }

            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                super.doUpdateVisitedHistory(view, url, isReload)
                val base = url?.substringBefore("#") ?: ""
                if (base != lastInjectedBaseUrl) {
                    lastInjectedBaseUrl = base
                    injectMentalgram(view)
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    val hasAudio = ContextCompat.checkSelfPermission(
                        this@MainActivity,
                        Manifest.permission.RECORD_AUDIO
                    ) == PackageManager.PERMISSION_GRANTED

                    if (hasAudio) {
                        request.grant(request.resources)
                    } else {
                        pendingWebPermission = request
                        requestAppPermissions()
                    }
                }
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                fileUploadCallback?.onReceiveValue(null)
                fileUploadCallback = filePathCallback
                return try {
                    val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                    }
                    filePickerLauncher.launch(intent)
                    true
                } catch (_: Exception) {
                    fileUploadCallback?.onReceiveValue(null)
                    fileUploadCallback = null
                    false
                }
            }
        }

        rootContainer.addView(
            webView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        rootContainer.addView(
            splashOverlay,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        setContentView(rootContainer)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        requestAppPermissions()
        webView.loadUrl(TELEGRAM_URL)

        if (slot == 1) {
            rootContainer.postDelayed({
                if (!isFinishing && !isDestroyed) {
                    showMentalsWelcomeDialog()
                }
            }, 350)
        }
    }

    private fun dp(value: Float): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, resources.displayMetrics).toInt()

    private fun showMentalsWelcomeDialog() {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(true)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)

        val cardBg = GradientDrawable().apply {
            setColor(Color.parseColor("#0B0305"))
            setStroke(dp(1.5f), Color.parseColor("#EF233C"))
            cornerRadius = dp(18f).toFloat()
        }

        val linkBoxBg = GradientDrawable().apply {
            setColor(Color.parseColor("#18060B"))
            setStroke(dp(1f), Color.parseColor("#6E1726"))
            cornerRadius = dp(10f).toFloat()
        }

        val joinBtnBg = GradientDrawable().apply {
            setColor(Color.parseColor("#EF233C"))
            cornerRadius = dp(10f).toFloat()
        }

        val secBtnBg = GradientDrawable().apply {
            setColor(Color.parseColor("#19090D"))
            setStroke(dp(1f), Color.parseColor("#541722"))
            cornerRadius = dp(10f).toFloat()
        }

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = cardBg
            setPadding(dp(22f), dp(22f), dp(22f), dp(20f))
        }

        val crest = TextView(this).apply {
            text = "👑 MENTALS DRAGON LAB"
            setTextColor(Color.parseColor("#FFB703"))
            textSize = 11f
            typeface = Typeface.MONOSPACE
            letterSpacing = 0.14f
            gravity = Gravity.CENTER
        }

        val title = TextView(this).apply {
            text = "Created by Mentals"
            setTextColor(Color.WHITE)
            textSize = 21f
            setTypeface(Typeface.DEFAULT_BOLD)
            gravity = Gravity.CENTER
            setPadding(0, dp(8f), 0, dp(4f))
        }

        val subtitle = TextView(this).apply {
            text = "Join our Official Telegram Group Chat for updates, VC & mods:"
            setTextColor(Color.parseColor("#C9969E"))
            textSize = 12.5f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(14f))
        }

        val gcHandle = TextView(this).apply {
            text = "@Mental_stuff_gc"
            setTextColor(Color.parseColor("#FFB703"))
            textSize = 15f
            typeface = Typeface.MONOSPACE
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            background = linkBoxBg
            setPadding(dp(14f), dp(10f), dp(14f), dp(10f))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dp(14f)
            }
        }

        val joinInAppBtn = Button(this).apply {
            text = "🔥 JOIN @Mental_stuff_gc"
            setTextColor(Color.WHITE)
            textSize = 13f
            isAllCaps = false
            setTypeface(Typeface.DEFAULT_BOLD)
            background = joinBtnBg
            setPadding(dp(12f), dp(11f), dp(12f), dp(11f))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dp(10f)
            }
            setOnClickListener {
                dialog.dismiss()
                val base = if ((webView.url ?: "").contains("/a/")) {
                    "https://web.telegram.org/a/"
                } else {
                    "https://web.telegram.org/k/"
                }
                webView.loadUrl(base + "#@Mental_stuff_gc")
            }
        }

        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        val openTgBtn = Button(this).apply {
            text = "Open in TG"
            setTextColor(Color.parseColor("#FFB703"))
            textSize = 11.5f
            isAllCaps = false
            background = secBtnBg
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dp(6f)
            }
            setOnClickListener {
                dialog.dismiss()
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("tg://resolve?domain=Mental_stuff_gc")))
                } catch (_: Exception) {
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/Mental_stuff_gc")))
                    } catch (_: Exception) {
                    }
                }
            }
        }

        val closeBtn = Button(this).apply {
            text = "Continue"
            setTextColor(Color.parseColor("#E4E4E7"))
            textSize = 11.5f
            isAllCaps = false
            background = secBtnBg
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = dp(6f)
            }
            setOnClickListener { dialog.dismiss() }
        }

        btnRow.addView(openTgBtn)
        btnRow.addView(closeBtn)

        card.addView(crest)
        card.addView(title)
        card.addView(subtitle)
        card.addView(gcHandle)
        card.addView(joinInAppBtn)
        card.addView(btnRow)

        val wrapper = FrameLayout(this).apply {
            setPadding(dp(20f), dp(20f), dp(20f), dp(20f))
            addView(card)
        }

        dialog.setContentView(wrapper)
        dialog.window?.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        dialog.show()
    }

    inner class MentalJsBridge {
        @JavascriptInterface
        fun getAccountSlot(): Int = this@MainActivity.getAccountSlot()

        @JavascriptInterface
        fun switchAccount(slot: Int) {
            runOnUiThread {
                val targetCls = when (slot) {
                    2 -> Slot2Activity::class.java
                    3 -> Slot3Activity::class.java
                    else -> MainActivity::class.java
                }
                if (this@MainActivity.javaClass == targetCls) return@runOnUiThread
                val intent = Intent(this@MainActivity, targetCls).apply {
                    addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                }
                startActivity(intent)
            }
        }

        @JavascriptInterface
        fun setVcKeepAwake(enabled: Boolean) {
            runOnUiThread {
                val svcIntent = Intent(this@MainActivity, DragonVcService::class.java)
                if (enabled) {
                    val hasMic = ContextCompat.checkSelfPermission(
                        this@MainActivity,
                        Manifest.permission.RECORD_AUDIO
                    ) == PackageManager.PERMISSION_GRANTED
                    if (!hasMic) {
                        requestAppPermissions()
                        return@runOnUiThread
                    }
                    try {
                        ContextCompat.startForegroundService(this@MainActivity, svcIntent)
                    } catch (_: Exception) {
                    }
                } else {
                    stopService(svcIntent)
                }
            }
        }

        @JavascriptInterface
        fun setVolTriggerMode(mode: String) {
            volTriggerMode = mode
        }

        @JavascriptInterface
        fun setAudioRoute(route: String) {
            runOnUiThread {
                try {
                    val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    when (route) {
                        "SPEAKER" -> {
                            am.mode = AudioManager.MODE_IN_COMMUNICATION
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                am.clearCommunicationDevice()
                                val spk = am.availableCommunicationDevices.firstOrNull {
                                    it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER
                                }
                                if (spk != null) am.setCommunicationDevice(spk)
                            }
                            @Suppress("DEPRECATION")
                            am.stopBluetoothSco()
                            @Suppress("DEPRECATION")
                            am.isBluetoothScoOn = false
                            @Suppress("DEPRECATION")
                            am.isSpeakerphoneOn = true
                        }
                        "BLUETOOTH" -> {
                            am.mode = AudioManager.MODE_IN_COMMUNICATION
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                val bt = am.availableCommunicationDevices.firstOrNull {
                                    it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                                        it.type == AudioDeviceInfo.TYPE_BLE_HEADSET
                                }
                                if (bt != null) am.setCommunicationDevice(bt)
                            } else {
                                @Suppress("DEPRECATION")
                                am.isSpeakerphoneOn = false
                                @Suppress("DEPRECATION")
                                am.startBluetoothSco()
                                @Suppress("DEPRECATION")
                                am.isBluetoothScoOn = true
                            }
                        }
                        "EARPIECE" -> {
                            am.mode = AudioManager.MODE_IN_COMMUNICATION
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                val ear = am.availableCommunicationDevices.firstOrNull {
                                    it.type == AudioDeviceInfo.TYPE_BUILTIN_EARPIECE
                                }
                                if (ear != null) am.setCommunicationDevice(ear)
                            }
                            @Suppress("DEPRECATION")
                            am.stopBluetoothSco()
                            @Suppress("DEPRECATION")
                            am.isBluetoothScoOn = false
                            @Suppress("DEPRECATION")
                            am.isSpeakerphoneOn = false
                        }
                        else -> {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                am.clearCommunicationDevice()
                            }
                            @Suppress("DEPRECATION")
                            am.stopBluetoothSco()
                            @Suppress("DEPRECATION")
                            am.isBluetoothScoOn = false
                            @Suppress("DEPRECATION")
                            am.isSpeakerphoneOn = false
                            am.mode = AudioManager.MODE_NORMAL
                        }
                    }
                } catch (_: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun enterPipMode() {
            runOnUiThread {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    try {
                        val params = PictureInPictureParams.Builder()
                            .setAspectRatio(Rational(9, 14))
                            .build()
                        enterPictureInPictureMode(params)
                    } catch (_: Exception) {
                    }
                }
            }
        }

        @JavascriptInterface
        fun boostRam() {
            runOnUiThread {
                webView.clearCache(false)
                System.gc()
                webView.reload()
                Toast.makeText(this@MainActivity, "⚡ RAM & Cache Boosted!", Toast.LENGTH_SHORT).show()
            }
        }

        @JavascriptInterface
        fun setScreenPrivacy(enabled: Boolean) {
            runOnUiThread {
                if (enabled) {
                    window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
                } else {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                }
            }
        }

        @JavascriptInterface
        fun saveRecording(base64Data: String, fileName: String) {
            runOnUiThread {
                try {
                    val cleanB64 = if (base64Data.contains(",")) base64Data.substringAfter(",") else base64Data
                    val bytes = Base64.decode(cleanB64, Base64.DEFAULT)
                    val safeName = fileName.replace(Regex("[^a-zA-Z0-9._-]"), "_")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        val values = ContentValues().apply {
                            put(MediaStore.MediaColumns.DISPLAY_NAME, safeName)
                            put(MediaStore.MediaColumns.MIME_TYPE, "audio/webm")
                            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                        }
                        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                        if (uri != null) {
                            contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                        }
                    } else {
                        @Suppress("DEPRECATION")
                        val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                        if (!dir.exists()) dir.mkdirs()
                        val outFile = File(dir, safeName)
                        FileOutputStream(outFile).use { it.write(bytes) }
                    }
                    Toast.makeText(this@MainActivity, "💾 Saved to Downloads: $safeName", Toast.LENGTH_LONG).show()
                } catch (_: Exception) {
                    Toast.makeText(this@MainActivity, "⚠️ Recording save failed", Toast.LENGTH_SHORT).show()
                }
            }
        }

        @JavascriptInterface
        fun requestScreenRec() {
            runOnUiThread {
                try {
                    val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                    screenRecLauncher.launch(mpm.createScreenCaptureIntent())
                } catch (_: Exception) {
                    Toast.makeText(this@MainActivity, "⚠️ Screen recorder unsupported", Toast.LENGTH_SHORT).show()
                }
            }
        }

        @JavascriptInterface
        fun appendScreenRecPcm(base64Pcm: String) {
            val svcIntent = Intent(this@MainActivity, DragonScreenRecService::class.java).apply {
                action = DragonScreenRecService.ACTION_APPEND_PCM
                putExtra(DragonScreenRecService.EXTRA_PCM_B64, base64Pcm)
            }
            try {
                startService(svcIntent)
            } catch (_: Exception) {
            }
        }

        @JavascriptInterface
        fun stopScreenRec(sampleRate: Int) {
            val svcIntent = Intent(this@MainActivity, DragonScreenRecService::class.java).apply {
                action = DragonScreenRecService.ACTION_STOP
                putExtra(DragonScreenRecService.EXTRA_SAMPLE_RATE, sampleRate)
            }
            try {
                startService(svcIntent)
            } catch (_: Exception) {
            }
        }

        @JavascriptInterface
        fun triggerRadarAlert(title: String, snippet: String) {
            runOnUiThread {
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                        vm.defaultVibrator.vibrate(VibrationEffect.createOneShot(220, VibrationEffect.DEFAULT_AMPLITUDE))
                    } else {
                        @Suppress("DEPRECATION")
                        val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            v.vibrate(VibrationEffect.createOneShot(220, VibrationEffect.DEFAULT_AMPLITUDE))
                        } else {
                            @Suppress("DEPRECATION")
                            v.vibrate(220)
                        }
                    }
                    val tg = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 85)
                    tg.startTone(ToneGenerator.TONE_PROP_BEEP2, 180)
                } catch (_: Exception) {
                }
            }
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (volTriggerMode != "OFF" && (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)) {
            val dir = if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) "UP" else "DOWN"
            webView.evaluateJavascript(
                "window.__mentalsOnVolKey && window.__mentalsOnVolKey('$dir','$volTriggerMode')",
                null
            )
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        webView.evaluateJavascript(
            "window.__mentalsOnPip && window.__mentalsOnPip($isInPictureInPictureMode)",
            null
        )
    }

    private fun injectMentalgram(view: WebView?) {
        if (view == null) return
        view.evaluateJavascript(themePayload, null)
        view.evaluateJavascript(dspPayload, null)
        view.evaluateJavascript(voiceChangerPayload, null)
        view.evaluateJavascript(powersPayload, null)
    }

    private fun requestAppPermissions() {
        val perms = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.MODIFY_AUDIO_SETTINGS
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            perms.add(Manifest.permission.BLUETOOTH_CONNECT)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val needed = perms.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (needed.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, needed.toTypedArray(), REQ_AUDIO_CODE)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_AUDIO_CODE) {
            val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            pendingWebPermission?.let { req ->
                if (granted) req.grant(req.resources) else req.deny()
                pendingWebPermission = null
            }
        }
    }

    override fun onPause() {
        super.onPause()
        CookieManager.getInstance().flush()
    }

    override fun onDestroy() {
        CookieManager.getInstance().flush()
        webView.destroy()
        super.onDestroy()
    }
}
