package com.mentals.telegram.dragon

class Slot2Activity : MainActivity() {
    override fun getAccountSlot(): Int = 2
}
