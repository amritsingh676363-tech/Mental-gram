plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.mentals.telegram.dragon"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.mentals.telegram.dragon"
        minSdk = 21
        targetSdk = 34
        versionCode = 7
        versionName = "3.3.0"
    }

    signingConfigs {
        create("release") {
            val ksPath = System.getenv("MENTALS_KEYSTORE_PATH")
            if (!ksPath.isNullOrBlank()) {
                storeFile = file(ksPath)
                storePassword = System.getenv("MENTALS_KEYSTORE_PASS") ?: "mentalsdragon"
                keyAlias = System.getenv("MENTALS_KEY_ALIAS") ?: "mentals"
                keyPassword = System.getenv("MENTALS_KEY_PASS") ?: "mentalsdragon"
                enableV1Signing = true
                enableV2Signing = true
                enableV3Signing = true
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            val ksPath = System.getenv("MENTALS_KEYSTORE_PATH")
            signingConfig = if (!ksPath.isNullOrBlank()) {
                signingConfigs.getByName("release")
            } else {
                signingConfigs.getByName("debug")
            }
        }
        debug {
            applicationIdSuffix = ".debug"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
}
