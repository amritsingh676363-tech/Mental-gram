// ==UserScript==
// @name         👑 MENTALS (Dragon Telegram Mic DSP)
// @namespace    https://web.telegram.org/
// @version      2.0.0
// @description  Dragon Style In-Built Telegram Web Voice Chat Mic DSP with Gain, EQ, Saturator, Limiter & Floating UI
// @author       MENTALS DRAGON LAB
// @match        https://web.telegram.org/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(() => {
  if (window.__tgVoiceUserscriptLoaded) return;
  window.__tgVoiceUserscriptLoaded = true;

  const STORAGE_KEY = 'mentals_dragon_userscript_cfg';
  const LIMITER_ENABLED = true;
  const PRESETS = {
    apexClear: {"micGain":210,"bass":28,"treble":46,"voiceClarity":68,"echo":0,"loudness":55,"noiseControl":26},
    dragonRoar: {"micGain":380,"bass":65,"treble":60,"voiceClarity":85,"echo":0,"loudness":88,"noiseControl":32},
    shadowStealth: {"micGain":250,"bass":52,"treble":38,"voiceClarity":64,"echo":10,"loudness":65,"noiseControl":42},
  };

  let settings = {"micGain":600,"bass":5,"treble":46,"voiceClarity":99,"echo":67,"loudness":100,"noiseControl":32};
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) settings = { ...settings, ...JSON.parse(saved) };
  } catch {}

  const activeEngines = new Set();

  function makeSoftClipCurve(drive) {
    const samples = 1024;
    const curve = new Float32Array(samples);
    const k = Math.max(0.5, drive);
    const norm = Math.tanh(k);
    for (let i = 0; i < samples; i++) {
      const x = (i * 2) / samples - 1;
      curve[i] = Math.tanh(k * x) / norm;
    }
    return curve;
  }

  function applySettings(engine, cfg) {
    const { ctx, gainNode, noiseFilter, bassFilter, clarityFilter, trebleFilter, compressor, makeupGain, saturator, limiter, echoWet, echoFeedback } = engine;
    if (!ctx || ctx.state === 'closed') return;
    const now = ctx.currentTime;
    gainNode.gain.setTargetAtTime(Math.max(0, Math.min(6.5, cfg.micGain / 100)), now, 0.02);
    noiseFilter.frequency.setTargetAtTime(20 + (cfg.noiseControl / 100) * 200, now, 0.02);
    bassFilter.gain.setTargetAtTime((cfg.bass / 100) * 18, now, 0.02);
    clarityFilter.gain.setTargetAtTime((cfg.voiceClarity / 100) * 16, now, 0.02);
    trebleFilter.gain.setTargetAtTime((cfg.treble / 100) * 15, now, 0.02);
    compressor.threshold.setTargetAtTime(-8 - (cfg.loudness / 100) * 28, now, 0.03);
    compressor.ratio.setTargetAtTime(2.0 + (cfg.loudness / 100) * 8.0, now, 0.03);
    makeupGain.gain.setTargetAtTime(1.0 + (cfg.loudness / 100) * 3.8, now, 0.02);
    saturator.curve = makeSoftClipCurve(LIMITER_ENABLED ? 1.8 + (cfg.loudness / 100) * 5.2 : 0.5);
    limiter.threshold.setTargetAtTime(LIMITER_ENABLED ? -0.6 : 0, now, 0.02);
    limiter.ratio.setTargetAtTime(LIMITER_ENABLED ? 20 : 1, now, 0.02);
    echoWet.gain.setTargetAtTime((cfg.echo / 100) * 0.65, now, 0.03);
    echoFeedback.gain.setTargetAtTime(Math.min(0.5, (cfg.echo / 100) * 0.45), now, 0.03);
  }

  if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
    const orig = navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);
    navigator.mediaDevices.getUserMedia = async function (constraints) {
      let mod = constraints;
      if (constraints && constraints.audio) {
        const audioObj = typeof constraints.audio === 'object' ? { ...constraints.audio } : {};
        mod = { ...constraints, audio: { ...audioObj, autoGainControl: false } };
      }
      let rawStream;
      try { rawStream = await orig(mod); } catch { rawStream = await orig(constraints); }
      if (!constraints || !constraints.audio || rawStream.getAudioTracks().length === 0) return rawStream;
      try {
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        const ctx = new AudioCtx();
        if (ctx.state === 'suspended') await ctx.resume();
        const source = ctx.createMediaStreamSource(rawStream);
        const gainNode = ctx.createGain();
        const noiseFilter = ctx.createBiquadFilter(); noiseFilter.type = 'highpass';
        const bassFilter = ctx.createBiquadFilter(); bassFilter.type = 'lowshelf'; bassFilter.frequency.value = 110;
        const clarityFilter = ctx.createBiquadFilter(); clarityFilter.type = 'peaking'; clarityFilter.frequency.value = 2450; clarityFilter.Q.value = 1.1;
        const trebleFilter = ctx.createBiquadFilter(); trebleFilter.type = 'highshelf'; trebleFilter.frequency.value = 6000;
        const compressor = ctx.createDynamicsCompressor(); compressor.knee.value = 12; compressor.attack.value = 0.002; compressor.release.value = 0.12;
        const makeupGain = ctx.createGain();
        const saturator = ctx.createWaveShaper(); saturator.oversample = '2x';
        const limiter = ctx.createDynamicsCompressor(); limiter.attack.value = 0.001; limiter.release.value = 0.06;
        const dryGain = ctx.createGain();
        const delayNode = ctx.createDelay(1.0); delayNode.delayTime.value = 0.22;
        const echoFeedback = ctx.createGain();
        const echoWet = ctx.createGain();
        const destination = ctx.createMediaStreamDestination();

        source.connect(gainNode);
        gainNode.connect(noiseFilter);
        noiseFilter.connect(bassFilter);
        bassFilter.connect(clarityFilter);
        clarityFilter.connect(trebleFilter);
        trebleFilter.connect(compressor);
        compressor.connect(makeupGain);
        makeupGain.connect(saturator);
        saturator.connect(dryGain);
        dryGain.connect(limiter);
        saturator.connect(delayNode);
        delayNode.connect(echoFeedback);
        echoFeedback.connect(delayNode);
        delayNode.connect(echoWet);
        echoWet.connect(limiter);
        limiter.connect(destination);

        const engine = { ctx, gainNode, noiseFilter, bassFilter, clarityFilter, trebleFilter, compressor, makeupGain, saturator, limiter, echoWet, echoFeedback };
        applySettings(engine, settings);
        activeEngines.add(engine);

        const out = new MediaStream();
        destination.stream.getAudioTracks().forEach((t) => {
          const stop = t.stop.bind(t);
          t.stop = () => {
            rawStream.getAudioTracks().forEach((r) => r.stop());
            activeEngines.delete(engine);
            if (ctx.state !== 'closed') ctx.close();
            stop();
          };
          out.addTrack(t);
        });
        rawStream.getVideoTracks().forEach((v) => out.addTrack(v));
        return out;
      } catch {
        return rawStream;
      }
    };
  }

  function mountUi() {
    if (window.top !== window || document.getElementById('mentals-us-mic-host')) return;
    const host = document.createElement('div');
    host.id = 'mentals-us-mic-host';
    host.style.cssText = 'position:fixed;bottom:18px;right:18px;z-index:999999;font-family:system-ui,sans-serif;';
    const shadow = host.attachShadow({ mode: 'open' });
    shadow.innerHTML = `
      <style>
        .fab { background:#12080a; color:#ffb703; border:1px solid #ef233c; padding:9px 14px; font-size:11px; font-weight:800; cursor:pointer; clip-path:polygon(8px 0, 100% 0, 100% calc(100% - 8px), calc(100% - 8px) 100%, 0 100%, 0 8px); }
        .panel { display:none; width:290px; background:#070506; border:1px solid #63141f; padding:12px; color:#f4f4f5; }
        .panel.open { display:block; }
        .head { display:flex; justify-content:space-between; align-items:center; margin-bottom:10px; padding-bottom:8px; border-bottom:1px solid #63141f; }
        .presets { display:grid; grid-template-columns:repeat(3,1fr); gap:5px; margin-bottom:10px; }
        .presets button { background:#12080a; border:1px solid #63141f; color:#fff; padding:6px 4px; font-size:9px; font-weight:800; cursor:pointer; }
        .grid { display:grid; grid-template-columns:1fr 1fr; gap:6px; }
        .row { background:#12080a; border:1px solid #63141f; padding:6px; }
        .row.full { grid-column:1 / -1; }
        .row-top { display:flex; justify-content:space-between; font-size:9px; font-weight:700; margin-bottom:3px; }
        input[type=range] { width:100%; accent-color:#ef233c; }
      </style>
      <button class="fab" id="openBtn">👑 MENTALS</button>
      <div class="panel" id="panel">
        <div class="head"><strong style="font-size:13px;color:#fff">👑 MENTALS</strong><button id="closeBtn" style="background:none;border:1px solid #63141f;color:#ccc;padding:2px 8px;cursor:pointer;font-size:10px">HIDE</button></div>
        <div class="presets">
          <button data-p="apexClear">APEX CLEAR</button>
          <button data-p="dragonRoar">DRAGON ROAR</button>
          <button data-p="shadowStealth">SHADOW</button>
        </div>
        <div class="grid" id="sliders"></div>
      </div>
    `;
    const openBtn = shadow.getElementById('openBtn');
    const panel = shadow.getElementById('panel');
    const closeBtn = shadow.getElementById('closeBtn');
    const sliders = shadow.getElementById('sliders');
    const defs = [['micGain','DRAGON DRIVE',0,600,true],['bass','BASS PUNCH',0,100,false],['voiceClarity','VOCAL FANG',0,100,false],['treble','TREBLE EDGE',0,100,false],['loudness','LOUDNESS',0,100,false],['noiseControl','NOISE GATE',0,100,false],['echo','ECHO',0,100,false]];
    function saveAndSync() {
      try { localStorage.setItem(STORAGE_KEY, JSON.stringify(settings)); } catch {}
      activeEngines.forEach((e) => applySettings(e, settings));
    }
    function render() {
      sliders.innerHTML = '';
      defs.forEach(([k, lbl, min, max, isFull]) => {
        const d = document.createElement('div'); d.className = isFull ? 'row full' : 'row';
        d.innerHTML = `<div class="row-top"><span>${lbl}</span><span id="v-${k}" style="color:#ffb703">${settings[k]}%</span></div>`;
        const inp = document.createElement('input'); inp.type = 'range'; inp.min = min; inp.max = max; inp.value = settings[k];
        inp.addEventListener('input', (ev) => { settings[k] = Number(ev.target.value); shadow.getElementById('v-' + k).textContent = settings[k] + '%'; saveAndSync(); });
        d.appendChild(inp); sliders.appendChild(d);
      });
    }
    shadow.querySelectorAll('[data-p]').forEach((b) => b.addEventListener('click', () => {
      const p = b.getAttribute('data-p'); if (PRESETS[p]) { settings = { ...PRESETS[p] }; render(); saveAndSync(); }
    }));
    openBtn.addEventListener('click', () => { panel.classList.add('open'); openBtn.style.display = 'none'; });
    closeBtn.addEventListener('click', () => { panel.classList.remove('open'); openBtn.style.display = 'inline-block'; });
    render();
    document.documentElement.appendChild(host);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mountUi); else mountUi();
})();
