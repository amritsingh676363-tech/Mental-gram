// mentals_theme.js - Mentalgram Dangerous Dragon Dark Theme & Red Flame MENTALSGRAM Branding
(() => {
  if (window.__mentalgramThemeInstalled) return;
  window.__mentalgramThemeInstalled = true;

  const STYLE_ID = 'mentalgram-dragon-theme-css';
  const CSS_CONTENT = `
    :root, html, html.theme-dark, body, .theme-dark {
      --color-background: #060304 !important;
      --color-background-secondary: #0c0406 !important;
      --color-background-compact-menu: #130609 !important;
      --color-background-compact-menu-hover: rgba(239, 35, 60, 0.22) !important;
      --color-background-selected: rgba(239, 35, 60, 0.22) !important;
      --color-chat-hover: rgba(239, 35, 60, 0.14) !important;
      --color-chat-active: linear-gradient(90deg, rgba(239, 35, 60, 0.34), rgba(120, 8, 24, 0.22)) !important;
      --color-primary: #ef233c !important;
      --color-primary-shade: #b80c24 !important;
      --color-primary-opacity: rgba(239, 35, 60, 0.18) !important;
      --color-links: #ff4d6d !important;
      --color-borders: rgba(239, 35, 60, 0.28) !important;
      --color-borders-input: rgba(239, 35, 60, 0.42) !important;
      --color-text: #f8fafc !important;
      --color-text-secondary: #c9969e !important;
      --color-text-meta: #b37b85 !important;
      --color-message-outgoing: #2a0710 !important;
      --color-message-incoming: #110609 !important;
      --color-reply-own: rgba(255, 183, 3, 0.16) !important;
      --color-green: #ffb703 !important;
      --color-error: #ff1e42 !important;
    }

    body, #Main, #LeftColumn, #MiddleColumn, #RightColumn {
      background-color: #060304 !important;
      color: #f8fafc !important;
    }

    /* Dangerous Dragon Header Bar */
    .LeftMainHeader, .MiddleHeader, .GroupCallHeader, .CallHeader {
      background: linear-gradient(180deg, #160509 0%, #090305 100%) !important;
      border-bottom: 1px solid rgba(239, 35, 60, 0.38) !important;
      box-shadow: 0 4px 18px rgba(239, 35, 60, 0.16) !important;
    }

    /* Dragon Scale / Obsidian Ember Chat Background */
    .messages-layout, .MessageList {
      background:
        radial-gradient(circle at 50% 15%, rgba(239, 35, 60, 0.14), transparent 55%),
        repeating-linear-gradient(135deg, rgba(239, 35, 60, 0.03) 0px, rgba(239, 35, 60, 0.03) 1px, transparent 1px, transparent 18px),
        #050203 !important;
    }

    /* Chat Bubbles & Active Selection */
    .ListItem.selected .ListItem-button, .chat-item-clickable.selected {
      background: linear-gradient(90deg, rgba(239, 35, 60, 0.30), rgba(158, 0, 28, 0.14)) !important;
      border-left: 3px solid #ff2a4b !important;
    }

    .Badge, .unread-count {
      background: linear-gradient(135deg, #ff2a4b, #9e001c) !important;
      color: #ffffff !important;
      box-shadow: 0 0 10px rgba(255, 30, 66, 0.55) !important;
    }

    /* Composer & Buttons */
    .Composer, .message-input-wrapper {
      background: #110508 !important;
      border: 1px solid rgba(239, 35, 60, 0.35) !important;
      box-shadow: 0 0 14px rgba(239, 35, 60, 0.12) !important;
    }

    .Button.primary, button.primary, .send.main-button {
      background: linear-gradient(135deg, #ef233c, #9e001c) !important;
      color: #ffffff !important;
      box-shadow: 0 0 14px rgba(239, 35, 60, 0.45) !important;
    }

    /* Fiery Dragon Dark Typography for MENTALSGRAM */
    .mentalgram-brand-bar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 6px 14px 4px;
      background: linear-gradient(90deg, #160408 0%, #24060c 50%, #120407 100%);
      border-bottom: 1px solid rgba(239, 35, 60, 0.45);
      box-shadow: 0 2px 14px rgba(239, 35, 60, 0.25);
      user-select: none;
    }

    .mentalgram-flame-text {
      font-family: "Cinzel Decorative", "Impact", "Arial Black", "Trebuchet MS", sans-serif;
      font-weight: 900;
      font-style: italic;
      font-size: 17px;
      letter-spacing: 0.14em;
      text-transform: uppercase;
      background: linear-gradient(180deg, #fff3b0 0%, #ffb703 25%, #ff2a4b 62%, #8f0016 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      filter: drop-shadow(0 0 8px rgba(255, 28, 60, 0.92)) drop-shadow(0 2px 2px rgba(0, 0, 0, 0.95));
      line-height: 1.1;
    }

    .mentalgram-flame-tag {
      font-family: monospace;
      font-size: 9px;
      font-weight: 800;
      letter-spacing: 0.1em;
      color: #ffb703;
      border: 1px solid rgba(239, 35, 60, 0.55);
      background: rgba(239, 35, 60, 0.16);
      padding: 2px 6px;
      clip-path: polygon(4px 0, 100% 0, calc(100% - 4px) 100%, 0 100%);
    }
  `;

  function ensureStyle() {
    if (!document.head) return;
    document.documentElement.classList.add('theme-dark');
    if (!document.getElementById(STYLE_ID)) {
      const style = document.createElement('style');
      style.id = STYLE_ID;
      style.textContent = CSS_CONTENT;
      document.head.appendChild(style);
    }
  }

  function applyMentalgramBranding() {
    ensureStyle();

    if (document.title && document.title.toLowerCase().includes('telegram')) {
      document.title = '🔥 MENTALSGRAM';
    } else if (!document.title) {
      document.title = '🔥 MENTALSGRAM';
    }

    // 1. Mount MENTALSGRAM Red Flame bar above LeftMainHeader where Telegram logo/title sits
    const leftCol = document.getElementById('LeftColumn');
    if (leftCol && !document.getElementById('mentalgram-top-strip')) {
      const strip = document.createElement('div');
      strip.id = 'mentalgram-top-strip';
      strip.className = 'mentalgram-brand-bar';
      strip.innerHTML =
        '<span class="mentalgram-flame-text">🔥 MENTALSGRAM</span>' +
        '<span class="mentalgram-flame-tag">DRAGON EDITION</span>';
      leftCol.insertBefore(strip, leftCol.firstChild);
    }

    // 2. Replace any visible "Telegram" headings (e.g. Login / Auth / Settings headers)
    const candidates = document.querySelectorAll('h1, h2, h3, .title, .auth-form h1, .HeaderTitle');
    candidates.forEach((el) => {
      if (el.dataset.mentalgramDone) return;
      const txt = (el.textContent || '').trim();
      if (/^telegram(\s+web)?$/i.test(txt)) {
        el.dataset.mentalgramDone = '1';
        el.innerHTML = '<span class="mentalgram-flame-text">🔥 MENTALSGRAM</span>';
      }
    });
  }

  const observer = new MutationObserver(() => applyMentalgramBranding());
  if (document.documentElement) {
    observer.observe(document.documentElement, { childList: true, subtree: true });
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', applyMentalgramBranding);
  } else {
    applyMentalgramBranding();
  }
})();
