package com.mentals.telegram.dragon

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var splashOverlay: LinearLayout
    private var pendingWebPermission: PermissionRequest? = null
    private lateinit var dspPayload: String
    private lateinit var themePayload: String

    companion object {
        private const val REQ_AUDIO_CODE = 9001
        private const val TELEGRAM_URL = "https://web.telegram.org/a/"
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = Color.parseColor("#060304")
        window.navigationBarColor = Color.parseColor("#060304")
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        dspPayload = assets.open("mentals_dsp.js").bufferedReader().use { it.readText() }
        themePayload = assets.open("mentals_theme.js").bufferedReader().use { it.readText() }

        val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audioManager.mode = AudioManager.MODE_IN_COMMUNICATION

        val rootContainer = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#060304"))
        }

        webView = WebView(this).apply {
            setBackgroundColor(Color.parseColor("#060304"))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            settings.userAgentString =
                "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"
        }

        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(webView, true)
        }

        splashOverlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#060304"))

            val iconView = ImageView(this@MainActivity).apply {
                setImageResource(R.drawable.ic_launcher_fg)
                val sizePx = TypedValue.applyDimension(
                    TypedValue.COMPLEX_UNIT_DIP, 128f, resources.displayMetrics
                ).toInt()
                layoutParams = LinearLayout.LayoutParams(sizePx, sizePx)
            }

            val titleView = TextView(this@MainActivity).apply {
                text = "MENTALSGRAM"
                setTextColor(Color.parseColor("#EF233C"))
                textSize = 24f
                setTypeface(Typeface.SERIF, Typeface.BOLD_ITALIC)
                letterSpacing = 0.16f
                gravity = Gravity.CENTER
            }

            val subView = TextView(this@MainActivity).apply {
                text = "DRAGON ROAR VOICE ENGINE  •  MENTAL"
                setTextColor(Color.parseColor("#FFB703"))
                textSize = 11f
                typeface = Typeface.MONOSPACE
                letterSpacing = 0.12f
                gravity = Gravity.CENTER
                setPadding(0, 14, 0, 0)
            }

            addView(iconView)
            addView(titleView)
            addView(subView)
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                if (url.startsWith("https://web.telegram.org") || url.startsWith("https://oauth.telegram.org")) {
                    return false
                }
                if (url.startsWith("http://") || url.startsWith("https://") || url.startsWith("tg://")) {
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                    } catch (_: Exception) {
                    }
                    return true
                }
                return false
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                injectMentalgram(view)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                injectMentalgram(view)
                CookieManager.getInstance().flush()
                if (splashOverlay.visibility == View.VISIBLE) {
                    splashOverlay.animate()
                        .alpha(0f)
                        .setDuration(260)
                        .withEndAction { splashOverlay.visibility = View.GONE }
                        .start()
                }
            }

            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                super.doUpdateVisitedHistory(view, url, isReload)
                injectMentalgram(view)
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    val hasAudio = ContextCompat.checkSelfPermission(
                        this@MainActivity,
                        Manifest.permission.RECORD_AUDIO
                    ) == PackageManager.PERMISSION_GRANTED

                    if (hasAudio) {
                        request.grant(request.resources)
                    } else {
                        pendingWebPermission = request
                        requestMicPermissions()
                    }
                }
            }
        }

        rootContainer.addView(
            webView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        rootContainer.addView(
            splashOverlay,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        setContentView(rootContainer)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        requestMicPermissions()
        webView.loadUrl(TELEGRAM_URL)
    }

    private fun injectMentalgram(view: WebView?) {
        if (view == null) return
        view.evaluateJavascript(themePayload, null)
        view.evaluateJavascript(dspPayload, null)
    }

    private fun requestMicPermissions() {
        val needed = arrayOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.MODIFY_AUDIO_SETTINGS
        ).filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (needed.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, needed.toTypedArray(), REQ_AUDIO_CODE)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_AUDIO_CODE) {
            val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            pendingWebPermission?.let { req ->
                if (granted) req.grant(req.resources) else req.deny()
                pendingWebPermission = null
            }
        }
    }

    override fun onPause() {
        super.onPause()
        CookieManager.getInstance().flush()
    }

    override fun onDestroy() {
        CookieManager.getInstance().flush()
        val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audioManager.mode = AudioManager.MODE_NORMAL
        webView.destroy()
        super.onDestroy()
    }
}
